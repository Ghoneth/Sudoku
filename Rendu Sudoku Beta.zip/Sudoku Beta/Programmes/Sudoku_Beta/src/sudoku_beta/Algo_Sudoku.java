package sudoku_beta;

/**Classe mère des sudoku back-end pour generation et resolution.
 * @author Antoine
 **/
public class Algo_Sudoku {
    int[][] grille = new int[9][9];
    int solution;
    
    /** Constructeur contenant le sudoku ainsi que son nombre de solution.
    * @param sudokuBase La grille 9x9 que l'on veut definir pour le sudoku.
    **/
    public Algo_Sudoku (int[][] sudokuBase) {
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                grille[ligne][colonne]=sudokuBase[ligne][colonne];
            }
        }
        solution=0;
    }
    
    /** Methode simple permettant d'afficher un sudoku.
    **/
    public void afficherSudoku() {
        for (int ligne = 0; ligne < 9; ligne++) {
            System.out.print("{");
            for (int colonne = 0; colonne < 9; colonne++) {
                if (colonne==8) System.out.print(this.grille[ligne][colonne]);
                else System.out.print(this.grille[ligne][colonne]+ ", ");
            }
            System.out.println("}");
        }
    }
    
    /** Méthode testant si un algorithme remplit ou partiellement remplit est correct.
     * @param grille La grille 9x9 du sudoku
     * @param avecZero Variable définissant le type de test. Si elle est vrai on omet les zeros présents dans la
     * grille et on réalise un test pour un algorithme partiellement rempli. Si elle est fausse alors on teste la validité
     * normale d'un sudoku rempli.
     * @return Vrai si le sudoku ne comporte pas deux fois le même nombre dans la même ligne/colonne/bloc 3x3, et
     * Faux si c'est le cas.
     **/    
    public static boolean estValide (int [][] grille, boolean avecZero) { 
        for (int ligne = 0; ligne < 9; ligne++) {
           for (int colonne = 0; colonne < 9; colonne++) {
               if (grille[ligne][colonne]!=0) {
                   int valeur = grille[ligne][colonne];
                   for (int index=0; index<9; index++) {
                       if (grille[ligne][index]==valeur) if (index!=colonne) return false;
                       if (grille[index][colonne]==valeur) if (index!=ligne) return false;
                   }
                   int cLigne = ligne/3;
                   int cColonne = colonne/3;
                   for (int index=0+cLigne*3; index<3+cLigne*3; index++) {
                       for (int jndex=0+cColonne*3; jndex<3+cColonne*3; jndex++) {
                           if (grille[index][jndex]==valeur) if (index!=ligne && jndex!=colonne) return false;
                       }
                   }
               }
               else if (!avecZero) return false;
           }
       }
       return true;
    }
    
    /** Methode de lancement des methodes de resolution.
    * Création d'instances comprenant le sudoku à resoudre, prise de mesure du temps avant la resolution, lancement des 
    * resolutions par les deux algorithmes puis conclusion avec les deltas de resolution ou avec le manque de solution.
    * C'est ici que l'on peut décider si on veut afficher les nombres trouvés au fur et à mesure, si on veut
    * chercher toutes les solutions possibles et si on veut les afficher.
    * @param sudokuPartiellementVide La grille 9x9 que l'on veut definir pour le sudoku.
    * @return La solution la plus rapidement trouvée du sudoku.
    **/
    public static int[][] algoLancement (int [][] sudokuPartiellementVide) {
        PremAlgo premsudoku = new PremAlgo (sudokuPartiellementVide);
        System.out.println("Sudoku partiellement rempli : ");
        premsudoku.afficherSudoku();
        System.out.println();
        
        System.out.println("////");
        System.out.println("//// Premier Algo ////" );
        System.out.println("////");
        
        long tDebut = new java.util.Date().getTime();
        
        boolean affichageIterationPrem=false;
        boolean uneSeuleSolution=false;
        boolean affichageSolutionUn =true;
        boolean affichageSolutions =false;
        boolean testPourGenerer = false;
        premsudoku.PremResolverTest(affichageIterationPrem,uneSeuleSolution,affichageSolutionUn,affichageSolutions,testPourGenerer);
        System.out.println();
        
        if (premsudoku.solution>0) {
            System.out.println("L'algo a pris " + (premsudoku.tSolution - tDebut) + " milisecondes à trouver (et surtout afficher) la premiere solution");
        } 
        else {
            System.out.println("Il n'y a pas de solution");
            
        }
        System.out.println();
        
        DeuxAlgo deuxsudoku = new DeuxAlgo (sudokuPartiellementVide);
        System.out.println("////");
        System.out.println("//// Deuxieme Algo ////" );
        System.out.println("////");
        
        long tDebut2 = new java.util.Date().getTime();
        
        boolean affichageIterationDeux=false;
        deuxsudoku.DeuxResolver(affichageIterationDeux);
        System.out.println();
        
        if (deuxsudoku.solution==1) {
            System.out.println("L'algo a pris " + (deuxsudoku.tSolution - tDebut) + " milisecondes à trouver (et surtout afficher) la premiere solution");
        } else {
            System.out.println ("Il n'y a pas de solution, ou alors pas trouvé en 25secondes");
        }
        
        return premsudoku.grilleSolutionUn;
    }
}