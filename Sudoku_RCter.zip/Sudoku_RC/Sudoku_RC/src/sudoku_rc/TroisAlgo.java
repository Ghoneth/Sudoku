package sudoku_rc;

/**Classe du troisieme algorithme de résolution étendant Algo_Sudoku.
 * @author Antoine
 */
public class TroisAlgo extends Algo_Sudoku {
    int iteration=0;
    int[][] grilleSolutionUn;
    boolean[][] existeSurLigne = new boolean[9][10];
    boolean[][] existeSurColonne = new boolean[9][10];
    boolean[][] existeSurBloc = new boolean [9][10];
    String message;
    
    /** Constructeur pour le troisieme algorithme de resolution.
     * Appel du constructeur pere ainsi qu'ajout de listes de contraintes comportant les valeurs
     * dans chaque ligne/colonne/bloc et ajout d'une grille pour enregistrer la premiere solution trouvée.
     * @param sudokuPartiellementVide La grille 9x9 que l'on veut definir pour le sudoku.
     **/
    public TroisAlgo(int[][] sudokuPartiellementVide) {
        super(sudokuPartiellementVide);
        grilleSolutionUn= new int[9][9];
        for (int index = 0; index < 9; index++) {
            for (int jndex = 0; jndex < 10; jndex++) {
                existeSurLigne[index][jndex]=false;
                existeSurColonne[index][jndex]=false;
                existeSurBloc[index][jndex]=false;
            }
        }
    }
    
    /**Methode reinitialisant les listes de contraintes. 
     */
    public void ResetContraintes () {
        for (int index = 0; index < 9; index++) {
            for (int jndex = 0; jndex < 10; jndex++) {
                existeSurLigne[index][jndex]=false;
                existeSurColonne[index][jndex]=false;
                existeSurBloc[index][jndex]=false;
            }
        }
    }
    
    /**Methode d'implementation des liste de contraintes.
     * La methode va chercher sur chaque case du sudoku des
     * valeurs différentes de 0 et affecter un True aux listes
     * auxquelles les valeurs trouvées appartiennent : ligne,
     * colonne ou bloc. Ainsi on se retrouve avec des listes correspondantes
     * aux valeurs etants possible de rentrer dans les lignes, colonnes
     * et blocs. La méthode ResetContraintes() est lancé pour s'assurer
     * de partir sur une base juste.
    **/
    public void CreationContraintes () {
        ResetContraintes();
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grille[ligne][colonne]==0) {
                    for (int valeur = 1; valeur < 10; valeur++) {
                        for (int index = 0; index < 9; index++) {
                            if (this.grille[ligne][index]==valeur) existeSurLigne[ligne][valeur]=true;
                            if (this.grille[index][colonne]==valeur) existeSurColonne[colonne][valeur]=true;
                            int cLigne = ligne/3;
                            int cColonne = colonne/3;
                            for (int jndex=0+cLigne*3; jndex<3+cLigne*3; jndex++) {
                                for (int kndex=0+cColonne*3; kndex<3+cColonne*3; kndex++) {
                                    if (grille[jndex][kndex]==valeur) existeSurBloc[(3*(ligne/3))+(colonne/3)][valeur]=true;
                                }
                             }
                        }
                    }
                }
            }
        }
    }
    
    /** Méthode récursive résolvant un sudoku en testant chaque case une par une.
    * Pour chaque case de la grille 9x9 non vide, la méthode regarde dans les listes de
    * contraintes les valeurs qui peuvent être rentrés, s'il y en a une alors on l'affecte
    * et on passe à la case suivante et ainsi de suite jusqu'à la fin de la grille. Si
    * en revanche on ne trouve pas de valeurs verifiant les listes de contraintes alors
    * il faut revenir en arrière pour tester la valeur suivante possible de la case précédente et
    * ainsi de suite. Si finalement on revient au départ et qu’aucun nombre ne
    * convient, alors il n’y a pas de solution. <p>
    * 
    * Lorsque la premiere solution est trouvée, les variables tSolution ainsi que grilleSolutionUn sont définies. <p>
    * La méthode peut montrer les itérations de recherche pour la premiere solution. <p>
    * La méthode peut traiter la premiere solution comme une itération fausse et continue à chercher les autres solutions
    * que l'on peut afficher si souhaité. 
    * 
    * @param affichageIteration Definit si on veut afficher les nombres trouvés au fur et à mesure ou non.
    * @param uneSeuleSolution Definit si on ne cherche qu'une solution ou bien plusieurs.
    * @param affichageSolutionUn Definit si on souhaite afficher la premiere solution.
    * @param affichageSolutions Definit si on souhaite afficher toutes les solutions.
    * @param testPourGenerer Definit si le test ne sert juste à la generation d'algorithme, dans ce cas il s'arrete à la 2e solution trouvée.
    * @return La valeur de retour n'est seulement utile pour la récursivité, on ne s'en sert pas autrement.
     */
    public int ResolutionSudoku (boolean affichageIteration, boolean uneSeuleSolution, boolean affichageSolutionUn, boolean affichageSolutions, boolean testPourGenerer) {
        if (testPourGenerer) if (this.solution > 1) return 0;
        if (this.solution >9) {
            if (this.solution==10)  {
                message = "Trop de solution, l'algorithme s'arrête ici";
                Visuel.afficherMessage(message);
                solution++; // faux, mais bien utile et ne casse rien puisque solution n'est plus utilisé
            }
            return 0;
        }
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grille[ligne][colonne]==0) {
                    for (int valeur = 1; valeur < 10; valeur++) {
                        if (!existeSurLigne[ligne][valeur]&&!existeSurColonne[colonne][valeur]&&!existeSurBloc[(3*(ligne/3))+(colonne/3)][valeur]) {
                            this.grille[ligne][colonne]=valeur;
                            existeSurLigne[ligne][valeur] = existeSurColonne[colonne][valeur] = existeSurBloc[(3*(ligne/3))+(colonne/3)][valeur]= true;
                            if (!uneSeuleSolution) {
                                this.ResolutionSudoku(affichageIteration,uneSeuleSolution,affichageSolutionUn,affichageSolutions,testPourGenerer);
                            }
                            else {
                                if (this.ResolutionSudoku(affichageIteration,uneSeuleSolution,affichageSolutionUn,affichageSolutions,testPourGenerer)==0) return 0;
                            }
                            this.grille[ligne][colonne]=0;
                            existeSurLigne[ligne][valeur] = existeSurColonne[colonne][valeur] = existeSurBloc[(3*(ligne/3))+(colonne/3)][valeur]= false;
                        }
                    }
                    return 1;
                }
            }
        }
        solution++;
        this.tSolution=new java.util.Date().getTime();
        if (affichageSolutionUn) {
            if (solution==1) {
                for (int ligne = 0; ligne < 9; ligne++) {
                    for (int colonne = 0; colonne < 9; colonne++) {
                        grilleSolutionUn[ligne][colonne]=this.grille[ligne][colonne];
                    }
                }
                System.out.println();
            }
            if (solution>1) {
                message = "Il existe une " + this.solution+ "e solution";
                Visuel.afficherMessage(message);
                if (affichageSolutions) {
                    this.afficherSudoku();
                    System.out.println();
                }
            }
        }
        return 0;
    }
}