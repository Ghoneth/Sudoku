package sudoku_rc;

/**Classe du premier algorithme de résolution étendant Algo_Sudoku.
 * @author Antoine
 */
public class PremAlgo extends Algo_Sudoku {
    int iteration=0;
    int[][] grilleSolutionUn;
    String message;
   
    /** Constructeur pour le premier algorithme de resolution.
     * Appel du constructeur pere ainsi qu'ajout d'une
     * grille pour enregistrer la premiere solution trouvée.
     * @param sudokuPartiellementVide La grille 9x9 que l'on veut definir pour le sudoku.
     **/
    public PremAlgo (int[][] sudokuPartiellementVide) {
        super(sudokuPartiellementVide);
        grilleSolutionUn= new int[9][9];
    }
    
    /** Méthode récursive résolvant un sudoku en testant chaque case une par une.
    * Pour chaque case de la grille 9x9 non vide, la méthode rentre chaque nombre de 1 à 9 et effectue un test de validité du sudoku
    * (pas dans ligne, colonne et bloc 3x3), s’il valide les conditions on continue à la case suivante et ainsi
    * de suite jusqu’à la fin de la grille. Si en revanche on ne trouve pas de nombre validant les conditions alors il
    * faut revenir en arrière pour tester l’incrémentation de la case d’avant et ainsi de suite. Si finalement on
    * revient au départ et qu’aucun nombre ne convient, alors il n’y a pas de solution. <p>
    * 
    * Lorsque la premiere solution est trouvée, les variables tSolution ainsi que grilleSolutionUn sont définies. <p>
    * La méthode peut montrer les itérations de recherche pour la premiere solution. <p>
    * La méthode peut traiter la premiere solution comme une itération fausse et continue à chercher les autres solutions
    * que l'on peut afficher si souhaité.
    * 
    * @param affichageIteration Definit si on veut afficher les nombres trouvés au fur et à mesure ou non.
    * @param uneSeuleSolution Definit si on ne cherche qu'une solution ou bien plusieurs.
    * @param affichageSolutionUn Definit si on souhaite afficher la premiere solution.
    * @param affichageSolutions Definit si on souhaite afficher toutes les solutions.
    * @param testPourGenerer Definit si le test ne sert juste à la generation d'algorithme, dans ce cas il s'arrete à la 2e solution trouvée.
    * @return La valeur de retour n'est seulement utile pour la récursivité, on ne s'en sert pas autrement.
    **/
    public int ResolutionSudoku (boolean affichageIteration, boolean uneSeuleSolution, boolean affichageSolutionUn, boolean affichageSolutions, boolean testPourGenerer) {
        if (testPourGenerer) if (this.solution > 1) return 0;
        if (this.solution >9) {
            if (this.solution==10)  {
                message = "Trop de solution, l'algorithme s'arrête ici";
                Visuel.afficherMessage(message);
                solution++; // faux, mais bien utile et ne casse rien puisque solution n'est plus utilisé
            }
            return 0;
        }
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grille[ligne][colonne]==0) {
                    for (int valeur = 1; valeur < 10; valeur++) {
                        this.grille[ligne][colonne]=valeur;
                        if (!uneSeuleSolution) {
                            if (estValide(this.grille, true)) this.ResolutionSudoku(affichageIteration,uneSeuleSolution,affichageSolutionUn,affichageSolutions,testPourGenerer);
                            if (ligne==9 && colonne==9) return 0;
                        }
                        else {
                            if (estValide(this.grille, true)&&this.ResolutionSudoku(affichageIteration,uneSeuleSolution,affichageSolutionUn,affichageSolutions,testPourGenerer)==0) return 0;
                        }
                        this.grille[ligne][colonne]=0;
                    }
                    return 1;
                }
            }
        }
        solution++;
        this.tSolution=new java.util.Date().getTime();
        if (affichageSolutionUn) {
            if (solution==1) {
                for (int ligne = 0; ligne < 9; ligne++) {
                    for (int colonne = 0; colonne < 9; colonne++) {
                        grilleSolutionUn[ligne][colonne]=this.grille[ligne][colonne];
                    }
                }
                System.out.println();
            }
            if (solution>1) {
                message = "Il existe une " + this.solution+ "e solution";
                Visuel.afficherMessage(message);
                if (affichageSolutions) {
                    this.afficherSudoku();
                    System.out.println();
                }
            }
        }
        return 0;
    }
}