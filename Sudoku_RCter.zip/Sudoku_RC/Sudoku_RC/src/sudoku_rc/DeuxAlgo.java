package sudoku_rc;
import java.util.Random;

/**Classe du deuxieme algorithme de résolution étendant Algo_Sudoku.
 * @author Antoine
 */
public class DeuxAlgo extends Algo_Sudoku {
    int[][] grilleDeBase;
    int doublonSommeTOTAL;
    int iteration=0;
    String message;
    
    /** Constructeur pour le deuxieme algorithme de resolution.
     * Appel du constructeur père ainsi qu'ajout d'une variable du nombre de doublon
     * compris dans le sudoku et sauvegarde du sudoku de base.
     * @param sudokuPartiellementVide La grille 9x9 que l'on veut definir pour le sudoku.
     **/
    public DeuxAlgo (int[][] sudokuPartiellementVide) {
        super(sudokuPartiellementVide);
        grilleDeBase=sudokuPartiellementVide;
        doublonSommeTOTAL=0;
    }
    
    /** Methode simple testant si un nombre est dans une ligne du sudoku.
     * @param i Nombre à tester.
     * @param ligneI Ligne à tester.
     * @return Vrai si le nombre n'est pas déjà dans la ligne, Faux si il l'est.
     */
    public boolean PasDansLigne (int i, int ligneI) {
        for (int index = 0; index < 9; index++) {
            if (this.grille[ligneI][index]==i) return false;
        }
        return true;
    }
    
    /** Methode comptant le nombre de doublon par ligne, colonne et bloc 3x3.
     **/
    public void TestDoublons () {
        doublonSommeTOTAL=0;
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                int valeur = this.grille[ligne][colonne];
                for (int index=0; index<9; index++) {
                    if (this.grille[index][colonne]==valeur) if (index!=ligne) {
                        doublonSommeTOTAL++;
                        continue;
                    }
                }
                int cLigne = ligne/3;
                int cColonne = colonne/3;
                for (int index=0+cLigne*3; index<3+cLigne*3; index++) {
                    for (int jndex=0+cColonne*3; jndex<3+cColonne*3; jndex++) {
                        if (this.grille[index][jndex]==valeur) if (index!=ligne && jndex!=colonne) {
                            doublonSommeTOTAL++;
                            continue;
                        }
                    }
                }
            }
        }
        doublonSommeTOTAL=doublonSommeTOTAL/2;
    }

    /** Méthode stochastique résolvant un sudoku.
     * La methode commence par remplir chaque case vide en ne créant pas de doublon dans les lignes.
     * Algo_Sudoku.TestDoublons est lancé pour trouver le nombre de doublon, et donc d'erreur dans la grille. On intervertit 2 nombres
     * d'une même ligne ne faisant pas parties du sudoku de base et on refait Algo_Sudoku.TestDoublons. S'il y a moins de doublons
     * qu'avant la permutation, alors on garde le changement. S'il y a plus de doublons, alors il y a une petite chance
     * pour que l'on garde le changement également. Une fois que le nombre de doublon est réduit à 0, la solution est trouvée.
     * La méthode s'arrete apres 25secondes sans trouver de solution. <p>
     * 
     * Lorsque la premiere solution est trouvée, la variable tSolution est définie. <p>
     * La méthode peut montrer les itérations de recherche pour la premiere solution. <p>
     * La méthode ne peut pas chercher les autres solutions.
     * 
     * @param affichageIteration Definit si on veut afficher les nombres trouvés au fur et à mesure ou non.
     */
    public int ResolutionSudoku(boolean affichageIteration, boolean uneSeuleSolution, boolean affichageSolutionUn, boolean affichageSolutions, boolean testPourGenerer) {
        long tdebut = new java.util.Date().getTime();
        if (!this.estValide(this.grille, true)) return 0;
        Random rand = new Random();
         for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grilleDeBase[ligne][colonne]==0) {
                    int i = rand.nextInt(9)+1;
                    while (!PasDansLigne(i, ligne)) i = rand.nextInt(9)+1;
                    this.grille[ligne][colonne]=i;
                }
            }
        }
        this.TestDoublons();
        int doublonSommeTOTALBefore;
        int colonneOne;
        int colonneTwo;
        int ligne;
        int temp;
        double u;
        while (true) {
            //double T=1;
            //while (T>0) {
            doublonSommeTOTALBefore = doublonSommeTOTAL;
            ligne = rand.nextInt(9);

            while (true) {
                colonneOne = rand.nextInt(9);
                colonneTwo = rand.nextInt(9);
                if (this.grilleDeBase[ligne][colonneOne]==0&&
                        this.grilleDeBase[ligne][colonneTwo]==0&&
                        colonneOne!=colonneTwo) break;
            }
            temp = this.grille[ligne][colonneOne];
            this.grille[ligne][colonneOne]=this.grille[ligne][colonneTwo];
            this.grille[ligne][colonneTwo]=temp;

            this.TestDoublons();
            if (doublonSommeTOTALBefore>=doublonSommeTOTAL) {
                if (doublonSommeTOTAL==0) {
                    System.out.println();
                    this.TestDoublons();
                    solution++;
                    this.tSolution=new java.util.Date().getTime();
                    return 0;
                }
                continue;
            }
            else {
                u = Math.random();
                //if (u<Math.exp((doublonSommeTOTALBefore-doublonSommeTOTAL)/T)) {
                if (u<Math.exp((doublonSommeTOTALBefore-doublonSommeTOTAL)/0.4)) {
                    continue;
                }
            }
            temp = this.grille[ligne][colonneOne];
            this.grille[ligne][colonneOne]=this.grille[ligne][colonneTwo];
            this.grille[ligne][colonneTwo]=temp;
            this.TestDoublons();
            if (new java.util.Date().getTime()-tdebut>10000) return 0;
        //T=T-0.05;
        //}
        }
    }
}