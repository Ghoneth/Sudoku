package sudoku_rc;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**Classe créant la grille affichée du sudoku implementant l'interface MouseListener permettant de prendre en compte
 * les actions de la souris sur la grille.
 * @author Fanny
 **/
public class Grille extends Panneau implements MouseListener{
    final int MARGE = 50;
    final int PAS = 45;
    int[][] grilleSudoku;
    int x;
    int y;
    boolean peutRemplir = false;
    String message;
    
    /**Constructeur créant le panneau contenant la grille.
     * Le constructeur lance addMouseListener permettant de prendre en compte
     * les actions de la souris sur le panneau grille.
     * @param largeur Largeur du panneau.
     * @param hauteur Hauteur du panneau.
     **/
    public Grille(int largeur, int hauteur) {
        super(largeur, hauteur);
        this.addMouseListener(this);
    }
    
    /** Methode permettant de remplacer la grille affichée par une nouvelle grille.
     * @param tableau La nouvelle grille du sudoku à mettre en place.
     **/
    public void recupererTableau(int[][] tableau){
        grilleSudoku = tableau;
    }
    
    /** Methode permettant d'ajouter une valeur dans une grille.
     * @param tableau La grille 9x9 du sudoku.
     * @param colonne Colonne de la case à remplacer.
     * @param ligne Ligne de la case à remplacer.
     * @param nouvelleValeur Valeur de la case à mettre en place.
     * @return La grille 9x9 du sudoku modifiée.
     **/
    public int [][] modifierTableau(int [][] tableau, int colonne, int ligne, int nouvelleValeur) {
        tableau[ligne][colonne] = nouvelleValeur;
        return tableau;
    }
    
    /**Methode permettant de chercher la valeur d'une case dans la grille. 
     * @param tableau La grille 9x9 du sudoku.
     * @param ligne Ligne de la case.
     * @param colonne Colonne de la case.
     * @return La valeur de la case cherchée.
     **/
    public String obtenirCaractere(int[][] tableau, int ligne, int colonne) {
        int valeur = tableau[ligne][colonne];
        String caractere = String.valueOf(valeur);
        return caractere;
    }
    
    
    /**Methode permettant de tester si un caractère vaut 0.
     * @param texte le caractère à tester.
     * @return un booléen.
     **/    
    public boolean caractereNul(String texte) {
        if (texte.equals(String.valueOf(0))) {
            return true; }
        return false;
    }
    
    /**Methode permettant de copier une grille sans la lier à sa copie.
     * @param tableau La grille à copier.
     * @return La grille copiée.
     **/
    public int[][] copierTableau(int[][] tableau) {
        int [][]copie = new int[9][9];
        for (int casex = 0; casex < 9; casex++){
            copie[casex] = tableau[casex].clone();}
        return copie;
    }
    
    /** Methode affichant les lignes de la grille 9x9 dans le panneau.
     * @param g Pinceau.
     **/
    public void afficherGrille(Graphics g) {
        for (int coord = 0; coord < 10 ; coord ++) {
            g.drawLine(MARGE + PAS*coord, MARGE, MARGE + PAS*coord, MARGE + PAS*9);
            g.drawLine(MARGE, MARGE + PAS*coord, MARGE + PAS*9, MARGE + PAS*coord);
            if (coord == 0 || coord == 3 || coord == 6 || coord == 9) {
                g.drawLine(MARGE + PAS*coord - 1, MARGE, MARGE + PAS*coord - 1, MARGE + PAS*9);
                g.drawLine(MARGE + PAS*coord + 1, MARGE, MARGE + PAS*coord + 1, MARGE + PAS*9);
                g.drawLine(MARGE, MARGE + PAS*coord - 1, MARGE + PAS*9, MARGE + PAS*coord - 1);
                g.drawLine(MARGE, MARGE + PAS*coord + 1, MARGE + PAS*9, MARGE + PAS*coord + 1);}
        }
    }
    
    /** Methode affichant les valeurs du sudoku dans la grille dans le tableau.
     * Lancement de Grille.afficherGrille(g) pour afficher les lignes de la grille dans le panneau. 
     * La methode appelle ensuite Grille.obtenirCaractere(tableau,ligne,colonne) pour chaque case de la grille en argument et
     * l'affiche dans les coordonnées de sa case.
     * @param g Pinceau.
     * @param tableau La grille 9x9 du sudoku à afficher.
     */
    public void afficherTableau(Graphics g, int[][] tableau) {    
        String texte;
        int abscisse;
        int ordonnee;
        afficherGrille(g);
        for (int nbcolonne = 0; nbcolonne < 9 ; nbcolonne ++) {
            for (int nbligne = 0; nbligne < 9 ; nbligne ++) {
                texte = obtenirCaractere(tableau, nbligne, nbcolonne);
                if (caractereNul(texte) == false) {
                    abscisse = MARGE+PAS*1/3 + PAS*nbcolonne;
                    ordonnee = MARGE+PAS*2/3 + PAS*nbligne;
                    g.drawString(texte, abscisse, ordonnee);} } }
    }
    
    /**Methode permettant de rafraichir la grille affichée.
     * @param g Pinceau.
     */
    public void effacerGraphique(Graphics g) {
        removeAll();
        repaint();
    }
    
    /**Methode permettant de parametrer le pinceau.
     * Parametrage de la police, de la taille d'écriture et de la couleur.
     * @param g Pinceau.
     **/
    public void changerPinceau(Graphics g, String couleur) {
        Font fonte = new Font(" TimesRoman ",Font.PLAIN,25);
        g.setFont(fonte);
        if (couleur.equals("noir")) {
            g.setColor(Color.black);}
        else if (couleur.equals("blanc")) {
            g.setColor(Color.white);}
    }
   
    
    /**Methode lancant l'affichage du panneau de la grille.
     * La méthode appelle Grille.changerPinceau(g) pour prendre le parametrage adéquate puis
     * appelle Grille.afficherTableau(g,tableau) pour afficher la grille à sa place dans le panneau.
     * @param g Pinceau.
     **/
    @Override public void paintComponent(Graphics g) {
        changerPinceau(g, "noir");
        Graphics g1 = g;
        super.paintComponent(g1);
        afficherTableau(g, grilleSudoku);
        changerPinceau(g, "blanc");
        afficherTableau(g, Visuel.tableauTest);
    }
    
    /**Methode implementant l'action clic de la souris dans la grille.
     * La méthode lance les methodes testant si le joueur est en droit de remplir la grille,
     * si le clic est à l'interieur de la grille et si la case cliquée peut etre modifiée.
     * Si un des tests precedents est faux alors un message d'explications du problème est affiché.
     * Autrement la méthode lance Visuel.entrerNombre(grille,x,y) pour rentrer le nombre dans la case cliquée.
     * @param e Action clic de la souris.
     **/
    @Override public void mouseClicked(MouseEvent e) {
        if (peutRemplir == true) {
            x = e.getX();
            y = e.getY();
            boolean dansGrille = testClickGrille(x,y);
            if (dansGrille == true) {
                boolean dansCaseVide = testClickCase(x,y);
                if (dansCaseVide == false) {
                    message = "Erreur, veuillez cliquez sur une case vide.";
                    Visuel.afficherMessage(message);}
                else{
                    Visuel.entrerNombre(this, x, y);}}
            else{
                message = "Erreur, veuillez cliquez dans la grille de sudoku.";
                Visuel.afficherMessage(message);}}
        else{
            message = "Erreur, vous ne pouvez pas remplir la grille.";
            Visuel.afficherMessage(message);}
    }
    
    /**Methode trouvant la colonne de cases dans laquelle l'abscisse en argument est.
     * @param coordX Abscisse d'une coordonnée
     * @return La colonne de cases dans laquelle l'abscisse est.
     */
    public int convertirX(int coordX) {
        int xcase = 0;
	for (int carre = 0; carre < 10; carre++) {
            if ((coordX > MARGE+PAS*carre) && (coordX < MARGE+PAS*(carre+1))) {
                xcase = carre;
                break;
            } 
        }
	return xcase;
    }
    
    /**Methode trouvant la ligne de cases dans laquelle l'ordonnée en argument est.
     * @param coordY Ordonnée d'une coordonnée
     * @return La ligne de cases dans laquelle l'ordonné est.
     */
    public int convertirY(int coordY) {
        int ycase = 0;
	for (int carre = 0; carre < 10; carre++) {
            if ((coordY > MARGE+PAS*carre) && (coordY < MARGE+PAS*(carre+1))) {
                ycase = carre;
                break;} 
        }
	return ycase;
    }
    
    /**Methode trouvant l'abscisse minimum d'une colonne de cases.
     * @param caseX Colonne de case
     * @return L'abscisse minimum de la colonne de cases.
     **/
    public int convertirAbscisseMin(int caseX) {
        int abscisseMin = MARGE + PAS * caseX;
        return abscisseMin;
    }
    
    /**Methode trouvant l'ordonnée minimum d'une ligne de cases.
     * @param caseY Ligne de case
     * @return L'ordonnée minimum de la ligne de cases.
     **/    
    public int convertirOrdonneeMin(int caseY) {
        int ordonneeMin = MARGE + PAS * caseY;
        return ordonneeMin;
    }
    
    /**Methode testant si le clic du joueur est à l'intérieur de la grille.
     * @param x Abscisse du clic
     * @param y Ordonnée du clic
     * @return Vrai si le clic est à l'intérieur de la grille, Faux si non.
     **/
    public boolean testClickGrille(int x, int y){
        if(x > MARGE && x < MARGE + 9*PAS && y > MARGE && y < MARGE + 9*PAS){
            return true;}
        else{
            return false;}
    }
    
    /**Methode testant si la case cliquée par le joueur n'est pas déjà remplie dans le sudoku de base.
     * @param x Abscisse du clic
     * @param y Ordonnée du clic
     * @return Vrai si la case peut être modifiée, Faux si non.
     **/
    public boolean testClickCase(int x, int y){
        int colonne = convertirX(x);
        int ligne = convertirY(y);
        if (Visuel.tableauTest[ligne][colonne]==0) {
            return true;}
        else{
            return false;} 
    }
    
    /**Methode permettant de lancer l'ajout d'une valeur dans une grille 9x9.
     * La méthode va convertir l'abscisse et l'ordonnée du clic en ligne et colonne de la case à modifier.
     * On va ensuite lancer les méthode Grille.modifierTableau(tableau,x,y,nombre) et
     * Grille.recupererTableau(tableau) afin d'effectuer le changement de valeur dans la grille puis l'afficher.
     * @param tableauARemplir La grille du sudoku à modifier.
     * @param nombre Le nombre à mettre en place
     */
    public void remplirGrille(int[][] tableauARemplir, int nombre) {
        int caseX, caseY, coordX, coordY;
        coordX = x;
        coordY = y;
        caseX = convertirX(coordX);
        caseY = convertirY(coordY);
        modifierTableau(tableauARemplir, caseX, caseY, nombre);
        recupererTableau(tableauARemplir);
    }
    
    /**Methode non utilisée.
     * @param e Néant.
     **/
    @Override public void mousePressed(MouseEvent e) {}
    /**Methode non utilisée.
     * @param e Néant.
     **/    
    @Override public void mouseReleased(MouseEvent e) {}
    /**Methode non utilisée.
     * @param e Néant.
     **/
    @Override public void mouseEntered(MouseEvent e) {}
    /**Methode non utilisée.
     * @param e Néant.
     **/
    @Override public void mouseExited(MouseEvent e) {}
}