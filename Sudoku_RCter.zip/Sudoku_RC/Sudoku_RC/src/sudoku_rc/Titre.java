package sudoku_rc;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

/** Classe créant le panneau titre "Sudoku Game".
 * @author Fanny
 **/
public class Titre extends Panneau {
    
    /**Constructeur créant un panneau titre.
     * @param largeur Largeur du panneau.
     * @param hauteur Hauteur du panneau.
     **/
    public Titre(int largeur, int hauteur) {
        super(largeur, hauteur);
    }
    
    /** Methode d'ajout de l'image titre "Sudoku Game".
     **/
    public void ajouterTitre() {
        String imgUrl="titre.png";
        ImageIcon icone = new ImageIcon(imgUrl);
        JLabel jlabel = new JLabel(icone, JLabel.CENTER);
        add(jlabel);
        validate();
    }
}