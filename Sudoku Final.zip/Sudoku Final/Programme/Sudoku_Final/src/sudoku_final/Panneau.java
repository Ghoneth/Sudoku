package sudoku_final;
import java.awt.Dimension;
import javax.swing.JPanel;

/**Classe créant un panneau.
 * @author Fanny
 **/
public class Panneau extends JPanel {
    
    /**Constructeur créant un panneau.
     * @param largeur Largeur du panneau.
     * @param hauteur Hauteur du panneau.
     **/
    public Panneau(int largeur, int hauteur) {
        this.setPreferredSize(new Dimension(largeur, hauteur));
        this.setVisible(true);
    }
}