package sudoku_final;
import static sudoku_final.Visuel.dessiner;

/**Classe principale de lancement du programme. 
 * @author Fanny
 **/
public class Sudoku_Final {
    
    /**Méthode principale lançant le programme.
     * @param args Néant.
     **/
    public static void main(String[] args) {
        dessiner();
    }
}