package sudoku_final;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JTextField ;

/**Classe créant les champs de texte pour les cases du sudoku implementant
 * KeyListener pour prendre en compte les actions du clavier.
 * @author Fanny
 **/
public class ChampTexte implements KeyListener {
    Grille grille;
    JTextField strNombre;
    Character[] listeNombre = {'1','2','3','4','5','6','7','8','9'};
    
    /**Constructeur créant un champ de texte pour une case du sudoku.
     * Le constructeur lance addKeyListener permettant de prendre en compte
     * les actions du clavier dans le champ de texte.
     * @param abscisse Abscisse minimum du champ de texte.
     * @param ordonnee Ordonnée minimum du champ de texte.
     * @param grille La grille 9x9 du sudoku.
     **/
    public ChampTexte(int abscisse, int ordonnee, Grille grille) {
        JTextField strNombre = new JTextField();
        Font font = new Font(" TimesRoman ", Font.PLAIN, 25);
        Color fond = new Color(40, 40, 40);
        this.grille = grille;
        strNombre.setFont(font);
        strNombre.setForeground(Color.black);
        strNombre.setBackground(fond);
        strNombre.setHorizontalAlignment(JTextField.CENTER); 
        strNombre.setBounds(abscisse, ordonnee, 45, 45);
        strNombre.addKeyListener(this);
        grille.add(strNombre);
        grille.repaint();
    }
    
    /**Methode implementant l'action du clavier dans le champ de texte.
     * La méthode ne prend pas en compte tout caractere different de 1 à 9 et
     * refuse un nombre déjà présent dans la ligne, colonne ou bloc 3x3 par test de validité.
     * Si refus, alors est affiché un message d'explication du probleme par lancement de Visuel.afficherMessage(message).
     * Si le caractère respecte les conditions, la méthode Visuel.grilleARemplir(grille,nombre) est lancée
     * puis Visuel.testSolution(grille) pour tester si l'utilisateur a trouvé la solution.
     * @param e Action du clavier.
     **/
    @Override public void keyReleased(KeyEvent e) {
        int nombre = 0;
        char texte = e.getKeyChar();
        for (int indice = 0; indice < 9; indice ++){
            if (listeNombre[indice].equals(texte)) {
                nombre = Character.getNumericValue(texte);
                break;
            }
            if (indice == 9) nombre = 0;
        }
        Visuel.grilleARemplir(grille, nombre);
        if (!Algo_Sudoku.estValide(grille.grilleSudoku)) {
            String message = "Ce nombre est déjà présent dans une ligne, colonne ou bloc";
            Visuel.afficherMessage(message,500,100);
            Visuel.grilleARemplir(grille, 0);
            return;
        }
        if (nombre!=0) Visuel.testSolution(grille);
    }
    
    /**Methode non utilisée.
     * @param e Néant
     **/
    @Override public void keyPressed(KeyEvent e) {}
    
    /**Methode non utilisée.
     * @param e Néant
     **/
    @Override public void keyTyped(KeyEvent e) {}
}