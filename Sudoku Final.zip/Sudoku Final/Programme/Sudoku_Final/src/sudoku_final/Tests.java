package sudoku_final;
import static sudoku_final.Algo_Sudoku.estValide;

/**Classe des tests unitaires sur les méthodes mathématiques. 
 * @author Antoine
 **/
public class Tests {
    
    /**Constructeur permettant de lancer les tests.
     * La méthode prend en argument un sudoku rempli avec sa version preremplie à une solution.
     * Elle lance ensuite tous les tests unitaires.
     * 
     * @param grilleRemplie Sudoku rempli connu.
     * @param grillePreRemplie Sudoku partiellement rempli à une solution connue.
     **/
    public Tests (int[][] grilleRemplie, int[][] grillePreRemplie) {
        testGenerationAleatoireMelange(grilleRemplie);
        testGenerationAleatoireSuppr(grilleRemplie);
        testGenerationNiveau();
        testResolutionAlgo1(grilleRemplie,grillePreRemplie);
        testResolutionAlgo2(grilleRemplie,grillePreRemplie);
        testResolutionAlgo3(grilleRemplie,grillePreRemplie);
    }
    
    /**Methode de test du melange de la classe GenererSudoku.
     * La méthode va créer une instance de GenererSudoku puis tester la validité du sudoku en argument
     * apres un GenererSudoku.melange(), qui est censée melanger une grille de sudoku tout en
     * gardant son caractère valide.
     * 
     * @param grilleRemplie Sudoku rempli connu.
     **/
    public void testGenerationAleatoireMelange (int[][] grilleRemplie) {
        System.out.print("Test du melange de la generation aléatoire : ");
        GenererSudoku grilleGeneree = new GenererSudoku(grilleRemplie);
        grilleGeneree.melange();
        if (!estValide(grilleGeneree.grille)) throw new AssertionError ("Probleme sur le mélange");
        System.out.println("Test bon");
    }
    
    /**Methode de test de la suppression d'element de la classe GenererSudoku.
     * La méthode va créer une instance de GenererSudoku puis tester l'unicité de la solution
     * apres un grilleGeneree.sudokuAleatoire(26), qui est censée supprimer des éléments d'une grille
     * de sudoku tout en gardant l'unicité de la solution.
     * 
     * @param grilleRemplie Sudoku rempli connu.
     **/
    public void testGenerationAleatoireSuppr(int[][] grilleRemplie) {
        System.out.print("Test de la suppression d'elements de la generation aléatoire : ");
        GenererSudoku grilleGeneree = new GenererSudoku(grilleRemplie);
        grilleGeneree.sudokuAleatoire(26);
        grilleGeneree.solution =0; //Reset de la solution
        grilleGeneree.creationContraintes(); //Reset des contraintes
        grilleGeneree.resolutionSudoku(false);
        if (grilleGeneree.solution !=1) throw new AssertionError ("Probleme sur le nombre de solution");
        System.out.println("Test bon");
    }
    
    /**Methode de test d'unicité de solution des grilles pré-enregistrées de la classe PreGrille.
     * La méthode teste l'unicité de solution pour chaque grille enregistrée dans la classe PreGrille
     * par une résolution par le premier algorithme.
     **/
    public void testGenerationNiveau() {
        System.out.println("Test de la generation par niveau : ");
        PreGrille preGrille = new PreGrille();
        for (int niveau =0;niveau<4;niveau++) {
            System.out.print("Niveau " + (niveau+1) + " - Numéro : ");
            for (int num=0;num<10;num++) {
                System.out.print((num+1) + " ");
                TroisAlgo troissudoku = new TroisAlgo (preGrille.pre_grilles[niveau][num]);
                troissudoku.resolutionSudoku(false);
                if (troissudoku.solution !=1) throw new AssertionError ("Probleme sur le nombre de solution");
            }
            System.out.println(": Test bon");
        }
    }
    
    /**Methode de test du premier algorithme de résolution.
     * La méthode teste l'unicité de solution trouvée par l'algorithme sur la grille en argument (dont nous connaissont
     * l'unicité de solution). Puis verifie que la solution trouvée est égale au sudoku rempli connu.
     * 
     * @param grilleRemplie Sudoku rempli connu.
     * @param grillePreRemplie Sudoku partiellement rempli à une solution connue.
     **/
    public void testResolutionAlgo1 (int[][] grilleRemplie, int[][] grillePreRemplie) {
        System.out.print("Test du premier algorithme de résolution : ");
        PremAlgo premsudoku = new PremAlgo (grillePreRemplie);
        premsudoku.resolutionSudoku(false);
        if (premsudoku.solution !=1) throw new AssertionError ("Probleme sur le nombre de solution");
        for (int ligne =0; ligne<9;ligne++) {
            for (int colonne =0; colonne<9; colonne++) {
                    if (premsudoku.grilleSolutionUn[ligne][colonne] != grilleRemplie[ligne][colonne])
                        throw new AssertionError ("Probleme sur solution trouvée");
            }
        }
        System.out.println("Test bon");
    }
    
    /**Methode de test du deuxieme algorithme de résolution.
     * La méthode teste l'unicité de solution trouvée par l'algorithme sur la grille en argument (dont nous connaissont
     * l'unicité de solution). Puis verifie que la solution trouvée est égale au sudoku rempli connu.
     * 
     * @param grilleRemplie Sudoku rempli connu.
     * @param grillePreRemplie Sudoku partiellement rempli à une solution connue.
     **/
    public void testResolutionAlgo2 (int[][] grilleRemplie, int[][] grillePreRemplie) {
        System.out.print("Test du deuxieme algorithme de résolution : ");
        DeuxAlgo deuxsudoku = new DeuxAlgo (grillePreRemplie);
        deuxsudoku.resolutionSudoku(false);
        if (deuxsudoku.solution !=1) throw new AssertionError ("Probleme sur le nombre de solution");
        for (int ligne =0; ligne<9;ligne++) {
            for (int colonne =0; colonne<9; colonne++) {
                    if (deuxsudoku.grilleSolutionUn[ligne][colonne] != grilleRemplie[ligne][colonne])
                        throw new AssertionError ("Probleme sur solution trouvée");
            }
        }
        System.out.println("Test bon");
    }

    /**Methode de test du troisieme algorithme de résolution.
     * La méthode teste l'unicité de solution trouvée par l'algorithme sur la grille en argument (dont nous connaissont
     * l'unicité de solution). Puis verifie que la solution trouvée est égale au sudoku rempli connu.
     * 
     * @param grilleRemplie Sudoku rempli connu.
     * @param grillePreRemplie Sudoku partiellement rempli à une solution connue.
     **/
    public void testResolutionAlgo3 (int[][] grilleRemplie, int[][] grillePreRemplie) {
        System.out.print("Test du troisieme algorithme de résolution : ");
        TroisAlgo troissudoku = new TroisAlgo (grillePreRemplie);
        troissudoku.resolutionSudoku(false);
        if (troissudoku.solution !=1) throw new AssertionError ("Probleme sur le nombre de solution");
        for (int ligne =0; ligne<9;ligne++) {
            for (int colonne =0; colonne<9; colonne++) {
                    if (troissudoku.grille[ligne][colonne] != grilleRemplie[ligne][colonne])
                        throw new AssertionError ("Probleme sur solution trouvée");
            }
        }
        System.out.println("Test bon");
    }
    
    /**Méthode main lançant les tests unitaires.
     * La méthode lance les tests depuis un sudoku rempli avec sa version preremplie à une solution.
     * @param args Néant.
     **/
    public static void main(String[] args) {
        int [][] grilleRemplie= {{5, 8, 6, 1, 2, 4, 3, 7, 9},
                                 {1, 3, 2, 6, 7, 9, 4, 5, 8},
                                 {9, 4, 7, 5, 3, 8, 2, 6, 1},
                                 {7, 2, 4, 3, 9, 5, 8, 1, 6},
                                 {8, 6, 1, 2, 4, 7, 5, 9, 3},
                                 {3, 5, 9, 8, 1, 6, 7, 2, 4},
                                 {2, 1, 8, 7, 6, 3, 9, 4, 5},
                                 {6, 9, 5, 4, 8, 2, 1, 3, 7},
                                 {4, 7, 3, 9, 5, 1, 6, 8, 2}};
        
        int [][] grillePreRemplie = {{0, 8, 0, 1, 0, 0, 3, 0, 0},
                                 {0, 3, 0, 0, 7, 0, 0, 5, 0},
                                 {0, 0, 7, 0, 0, 8, 0, 0, 0},
                                 {7, 0, 4, 0, 0, 0, 0, 1, 0},
                                 {0, 6, 1, 0, 0, 0, 0, 9, 3},
                                 {0, 0, 0, 0, 0, 0, 7, 0, 0},
                                 {0, 0, 0, 0, 0, 3, 9, 0, 0},
                                 {6, 0, 5, 0, 0, 2, 0, 0, 7},
                                 {0, 0, 3, 9, 0, 1, 0, 0, 2}};
        
        Tests test = new Tests(grilleRemplie,grillePreRemplie);
    }
}
