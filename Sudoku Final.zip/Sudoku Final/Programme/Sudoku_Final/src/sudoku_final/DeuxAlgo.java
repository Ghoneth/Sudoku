package sudoku_final;

/**Classe du deuxieme algorithme de résolution étendant Algo_Sudoku.
 * @author Antoine
 */
public class DeuxAlgo extends Algo_Sudoku {
    int iteration=0;
    int[][] grilleSolutionUn;
   
    /**Constructeur pour le deuxieme algorithme de resolution.
     * Simple appel du constructeur pere pour avoir une grille, le nombre de solution
     * ainsi que le temps de resolution. Ajout d'une
     * grille pour enregistrer la premiere solution trouvée.
     * @param sudokuPartiellementVide La grille 9x9 que l'on veut definir pour le sudoku.
     **/
    public DeuxAlgo (int[][] sudokuPartiellementVide) {
        super(sudokuPartiellementVide);
        grilleSolutionUn= new int[9][9];
    }
    
    /**Méthode récursive résolvant un sudoku en testant chaque case une par une.
    * Pour chaque case de la grille 9x9 non vide, la méthode rentre chaque nombre de 1 à 9 et effectue un test de validité du sudoku
    * (pas dans ligne, colonne et bloc 3x3) par lancement de la méthode estValide. S’il valide les conditions on continue à la case suivante
    * et ainsi de suite jusqu’à la fin de la grille. Si en revanche on ne trouve pas de nombre validant les conditions alors il
    * faut revenir en arrière pour tester l’incrémentation de la case d’avant et ainsi de suite. Si finalement on
    * revient au départ et qu’aucun nombre ne convient, alors il n’y a pas de solution. <p>
    * 
    * Lorsque la premiere solution est trouvée, les variables tSolution ainsi que grilleSolutionUn sont définies. <p>
    * La méthode traite la premiere solution comme une itération fausse et continue de chercher les autres solutions.
    * L'algorithme s'arrète apres la 10e solution trouvée.
    * 
    * @param testPourGenerer Variable obligatoire car présente dans méthode abstraite mais non utilisée.
    * @return La valeur de retour n'est utilisée que pour la récursivité, on ne s'en sert pas autrement.
    **/
    public int resolutionSudoku (boolean testPourGenerer) {
        if (this.solution >9) {
            if (this.solution==10) solution++; // faux, mais bien utile et ne casse rien puisque la variable solution n'est plus utilisée
            return 0;
        }
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grille[ligne][colonne]==0) {
                    for (int valeur = 1; valeur < 10; valeur++) {
                        this.grille[ligne][colonne]=valeur;
                        if (estValide(this.grille)) this.resolutionSudoku(testPourGenerer);
                        if (ligne==9 && colonne==9) return 0;
                        this.grille[ligne][colonne]=0;
                    }
                    return 1;
                }
            }
        }
        solution++;
        this.tSolution=new java.util.Date().getTime();
        if (solution==1) {
            for (int ligne = 0; ligne < 9; ligne++) {
                for (int colonne = 0; colonne < 9; colonne++) {
                    grilleSolutionUn[ligne][colonne]=this.grille[ligne][colonne];
                }
            }
        }
        return 0;
    }
}