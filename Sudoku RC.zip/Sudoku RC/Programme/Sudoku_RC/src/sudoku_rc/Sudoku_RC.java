package sudoku_rc;
import static sudoku_rc.Visuel.dessiner;

/**Classe principale de lancement du programme. 
 * @author Fanny
 **/
public class Sudoku_RC {
    
    /** Méthode principale lançant le programme.
     * @param args Néant.
     **/
    public static void main(String[] args) {
        dessiner();
    }
}