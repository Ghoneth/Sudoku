package sudoku_rc;

/**Classe mère des sudoku back-end pour generation et resolution.
 * @author Antoine
 **/
public abstract class Algo_Sudoku {
    int[][] grille = new int[9][9];
    int solution;
    long tSolution;
    
    /**Constructeur contenant le sudoku, son nombre de solution et une variable pour le temps de résolution.
    * @param sudokuBase La grille 9x9 que l'on veut definir pour le sudoku.
    **/
    public Algo_Sudoku (int[][] sudokuBase) {
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                grille[ligne][colonne]=sudokuBase[ligne][colonne];
            }
        }
        solution=0;
        tSolution=0;
    }
    
    /**Méthode testant si un algorithme rempli ou partiellement rempli est correct.
     * La méthode cherche des doublons sur les lignes, colonnes et bloc 3x3.
     * @param grille La grille 9x9 du sudoku
     * @return Vrai si le sudoku ne comporte pas deux fois le même nombre dans la même ligne/colonne/bloc 3x3, et
     * Faux si c'est le cas.
     **/    
    public static boolean estValide (int [][] grille) {
        for (int ligne = 0; ligne < 9; ligne++) {
           for (int colonne = 0; colonne < 9; colonne++) {
               if (grille[ligne][colonne]!=0) {
                   int valeur = grille[ligne][colonne];
                   for (int index=0; index<9; index++) {
                       if (grille[ligne][index]==valeur) if (index!=colonne) return false;
                       if (grille[index][colonne]==valeur) if (index!=ligne) return false;
                   }
                   int cLigne = ligne/3;
                   int cColonne = colonne/3;
                   for (int index=0+cLigne*3; index<3+cLigne*3; index++) {
                       for (int jndex=0+cColonne*3; jndex<3+cColonne*3; jndex++) {
                           if (grille[index][jndex]==valeur) if (index!=ligne && jndex!=colonne) return false;
                       }
                   }
               }
           }
       }
       return true;
    }
    
    /**Méthode abstraite de résolution de sudoku.
     * 
     * @param testPourGenerer Definit si le test ne sert juste à la generation d'algorithme, dans ce cas il s'arrete à la 2e solution trouvée.
     * @return La valeur de retour n'est utilisée que pour la récursivité, on ne s'en sert pas autrement.
     **/
    public abstract int resolutionSudoku(boolean testPourGenerer);
    
   /**Methode de lancement des methodes de resolution.
    * Création d'instances comprenant le sudoku à resoudre, prise de mesure du temps avant la resolution, lancement des 
    * resolutions par les trois algorithmes puis conclusion en enregistrant le message avec les deltas de resolution
    * ou avec le manque de solution.
    * 
    * @param sudokuPartiellementVide La grille 9x9 que l'on veut definir pour le sudoku.
    * @return La premiere solution du premiere algorithme.
    **/
    public static int[][] algoLancement (int [][] sudokuPartiellementVide) { 
        String message;
        boolean testPourGenerer=false;
        
        PremAlgo premsudoku = new PremAlgo (sudokuPartiellementVide);
        long tDebut = new java.util.Date().getTime();
        premsudoku.resolutionSudoku(testPourGenerer);
        if (premsudoku.solution>0) {
            message = "Premier algorithme : L'algo a pris " + (premsudoku.tSolution - tDebut) + " milisecondes à trouver la premiere solution";
            if(premsudoku.solution==11) message+= "\nIl a trouvé plus de 10 solution(s)\n";
            else message+= "\nIl a trouvé " + premsudoku.solution + " solution(s)\n";
        }
        else message = "Premier algorithme : Il n'y a pas de solution\n";
        
        DeuxAlgo deuxsudoku = new DeuxAlgo (sudokuPartiellementVide);
        long tDebut2 = new java.util.Date().getTime();
        deuxsudoku.resolutionSudoku(testPourGenerer);
        if (deuxsudoku.solution>0) {
            message += "\nDeuxième algorithme : L'algo a pris " + (deuxsudoku.tSolution - tDebut2) + " milisecondes à trouver la premiere solution";
            if(deuxsudoku.solution==11) message+= "\nIl a trouvé plus de 10 solution(s)\n";
            else message+= "\nIl a trouvé " + deuxsudoku.solution + " solution(s)\n";
        }
        else message += "\nDeuxième algorithme : Il n'y a pas de solution\n";
        
        TroisAlgo troissudoku = new TroisAlgo (sudokuPartiellementVide);
        long tDebut3 = new java.util.Date().getTime();
        troissudoku.resolutionSudoku(testPourGenerer);
        if (troissudoku.solution==1) {
            message += "\nTroisième algorithme : L'algo a pris " + (troissudoku.tSolution - tDebut3) + " milisecondes à trouver la premiere solution";
            message+= "\nCet algorithme ne peut trouver qu'une seule solution";
        } 
        else message += "\nTroisième algorithme : Il n'y a pas de solution, ou alors pas trouvé en 10secondes";
        
        Visuel.afficherMessage(message,600,200);
        return premsudoku.grilleSolutionUn;
    }
}