package sudoku_alpha;

import java.awt. *;
import javax.swing. *;

public class Titre extends Panneau {
    public Titre(int largeur, int hauteur, Visuel sudoku) {
        super(largeur, hauteur, sudoku);
    }
    
    public void ajouterTitre() {
        String imgUrl="titre.png";
        ImageIcon icone = new ImageIcon(imgUrl);
        JLabel jlabel = new JLabel(icone, JLabel.CENTER);
        add(jlabel);
        validate();
    }
}