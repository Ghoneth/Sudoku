package sudoku_alpha;

import java.awt. *;
import javax.swing. *;
import java.util.Scanner;

public class Visuel extends JFrame {
    public static Graphics g1 = null;
    static int [][] tableauVide = new int [9][9];
    static int [][] tableauTest = new int [9][9];
    static int [][] tableauEnCours;
    static boolean tableauACreer;
        
    public Visuel(int largeur, int hauteur) {
        this.setTitle("Jeu de sudoku");
        this.setSize(largeur, hauteur);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    
    public static boolean testErreur(int nombre) {
        if (nombre >= 0 && nombre <= 9) {
            return true;}
        return false;
    }
    
    public static int entrerNombre() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre compris entre 1 et 9:");
        return sc.nextInt();
    }
    
    public static void demarrage(Grille grille) {
        grille.effacerGraphique(g1);
        grille.recupererTableau(tableauEnCours);
    }
    
    public static void grilleTestAntoine(Grille grille) {
        grille.effacerGraphique(g1);
        int[][] tableauTemp = GenererSudoku.genererAleatoire();
        grille.recupererTableau(tableauTemp);
        tableauTest=tableauTemp;
    }
        
    public static void grilleResolutionAntoine(Grille grille) {
        grille.effacerGraphique(g1);
        int[][] tableauTemp = PremAlgo.Algo(tableauEnCours);
        grille.recupererTableau(tableauTemp);
        tableauEnCours=tableauTemp;
    }
    
    public static void grilleARemplir(Grille grille) {
        grille.effacerGraphique(g1);
        int nombre = entrerNombre();
        if (testErreur(nombre) == true){
            grille.remplirGrille(tableauEnCours, nombre);}
        else {
            System.out.println("Veuillez entrez un nombre compris entre 0 et 9 !");}
    }
    
    public static void dessiner() {
        Visuel fenetre = new Visuel (800, 800);
        Panneau panneau = new Panneau(800, 800, fenetre);
        Grille grille = new Grille(500, 500, fenetre);
        Boutons boutons = new Boutons(200,100, fenetre, grille);
        Titre titre = new Titre(800, 150, fenetre);
        grille.paint(g1);
        Color fond = new Color(90, 0, 0);
        
        panneau.setBackground(fond);
        titre.setOpaque(false);
        panneau.add(titre, BorderLayout.PAGE_START);
        grille.setOpaque(false);
        panneau.add(grille, BorderLayout.LINE_START);
        boutons.setOpaque(false);
        panneau.add(boutons, BorderLayout.LINE_END);
        fenetre.setContentPane(panneau);
        
        tableauEnCours = grille.copierTableau(tableauVide);
        demarrage(grille);
        boutons.BoutonsDebut();
        titre.ajouterTitre();
    }
}