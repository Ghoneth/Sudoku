package sudoku_alpha;

import java.awt. *;
import javax.swing. *;

public class Panneau extends JPanel {
    Visuel fenetre;
    
    public Panneau(int largeur, int hauteur, Visuel sudoku) {
        this.setPreferredSize(new Dimension(largeur, hauteur));
        this.setVisible(true);
        this.fenetre = sudoku;}
}