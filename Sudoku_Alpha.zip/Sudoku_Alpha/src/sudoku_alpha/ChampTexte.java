package sudoku_alpha;

import java.awt. *;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.* ;

public class ChampTexte 
                        implements KeyListener {
    Grille grille;
    JTextField strNombre;
    
    public ChampTexte(int abscisse, int ordonnee, Grille grille) {
        JTextField strNombre = new JTextField();
        Font font = new Font(" TimesRoman ", Font.PLAIN, 25);
        Color fond = new Color(90, 0, 0);
        this.grille = grille;
        
        strNombre.setFont(font);
        strNombre.setForeground(Color.black);
        strNombre.setBackground(fond);
        strNombre.setHorizontalAlignment(JTextField.CENTER); 
        strNombre.setBounds(abscisse, ordonnee, 45, 45);
        strNombre.addKeyListener(this);
        
        grille.add(strNombre);
        grille.repaint();
    }
    
    public void finEntrerNombre(Grille grille, int nombre) {
        Visuel.grilleARemplir(grille, nombre);
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int nombre = 0;
        char texte = e.getKeyChar();
        switch(texte) {
            case '0' :
                nombre = 0;
                break;
            case '1' :
                nombre = 1;
                break;
            case '2' :
                nombre = 2;
                break;
            case '3' :
                nombre = 3;
                break;
            case '4' :
                nombre = 4;
                break;
            case '5' :
                nombre = 5;
                break;
            case '6' :
                nombre = 6;
                break;
            case '7' :
                nombre = 7;
                break;
            case '8' :
                nombre = 8;
                break;
            case '9' :
                nombre = 9;
                break;
            default :
                System.out.println("Veuillez entrez un nombre compris entre 0 et 9 !");
                break;
            }
        finEntrerNombre(grille, nombre);
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}
