package sudoku_alpha;

import java.awt. *;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Grille extends Panneau 
                    implements MouseListener{
    
    final int MARGE = 50;
    final int PAS = 45;
    int[][] grilleSudoku;
    int x;
    int y;
    boolean peutRemplir = false;
        
    public Grille(int largeur, int hauteur, Visuel sudoku) {
        super(largeur, hauteur, sudoku);
        this.addMouseListener(this);
    }
    
    public void recupererTableau(int[][] tableau){
        grilleSudoku = tableau;
    }
    
    public int [][] modifierTableau(int [][] tableau, int colonne, int ligne, int nouvelleValeur) {
        tableau[ligne][colonne] = nouvelleValeur;
        return tableau;
    }
    
    public int obtenirValeur(int[][] tableau, int ligne, int colonne) {
        int valeur = tableau[ligne][colonne];
        return valeur;
    }
    
    public String obtenirCaractere(int[][] tableau, int ligne, int colonne) {
        int valeur = obtenirValeur(tableau, ligne, colonne);
        String caractere = String.valueOf(valeur);
        return caractere;
    }
    
    public int[][] copierTableau(int[][] tableau) {
        int [][]copie = new int[9][9];
        for (int casex = 0; casex < 9; casex++){
            copie[casex] = tableau[casex].clone();}
        return copie;
    }
    
    public void afficherGrille(Graphics g) {
        for (int coord = 0; coord < 10 ; coord ++) {
            g.drawLine(MARGE + PAS*coord, MARGE, MARGE + PAS*coord, MARGE + PAS*9);
            g.drawLine(MARGE, MARGE + PAS*coord, MARGE + PAS*9, MARGE + PAS*coord);
            if (coord == 0 || coord == 3 || coord == 6 || coord == 9) {
                g.drawLine(MARGE + PAS*coord - 1, MARGE, MARGE + PAS*coord - 1, MARGE + PAS*9);
                g.drawLine(MARGE + PAS*coord + 1, MARGE, MARGE + PAS*coord + 1, MARGE + PAS*9);
                g.drawLine(MARGE, MARGE + PAS*coord - 1, MARGE + PAS*9, MARGE + PAS*coord - 1);
                g.drawLine(MARGE, MARGE + PAS*coord + 1, MARGE + PAS*9, MARGE + PAS*coord + 1);}
        }
    }
    
    public void afficherTableau(Graphics g, int[][] tableau) {    
        String texte;
        int abscisse;
        int ordonnee;
        afficherGrille(g);
        for (int nbcolonne = 0; nbcolonne < 9 ; nbcolonne ++) {
            for (int nbligne = 0; nbligne < 9 ; nbligne ++) {
                texte = obtenirCaractere(tableau, nbligne, nbcolonne);
                abscisse = MARGE+PAS*1/3 + PAS*nbcolonne;
                ordonnee = MARGE+PAS*2/3 + PAS*nbligne;
                g.drawString(texte, abscisse, ordonnee);} }
    }
    
    public void effacerGraphique(Graphics g) {
        removeAll();
        repaint();
    }
    
    public void changerPinceau(Graphics g) {
        Font fonte = new Font(" TimesRoman ",Font.PLAIN,25);
        g.setFont(fonte);
        g.setColor(Color.black);
    }
    
    @Override
    public void paintComponent(Graphics g) {
        changerPinceau(g);
        Graphics g1 = g;
        super.paintComponent(g1);
        afficherTableau(g, grilleSudoku);
    }  
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if (peutRemplir == true) {
            x = e.getX();
            y = e.getY();
            if ( x > 50 && x < 455 && y > 50 && y < 455) {
                Visuel.EntrerNombre(this, x, y); }
            else {
                System.out.println("Erreur, veuillez cliquez dans la grille de sudoku");}}
        else{
            System.out.println("Erreur, vous ne pouvez pas remplir la grille");}
    }
    
    public int convertirX(int coordX) {
        int xcase = 0;
	for (int carre = 0; carre < 10; carre++) {
            if ((coordX > MARGE+PAS*carre) && (coordX < MARGE+PAS*(carre+1))) {
                xcase = carre;
                break; } 
        }
	return xcase;
    }
    
    public int convertirY(int coordY) {
        int ycase = 0;
	for (int carre = 0; carre < 10; carre++) {
            if ((coordY > MARGE+PAS*carre) && (coordY < MARGE+PAS*(carre+1))) {
                ycase = carre;
                break;} 
        }
	return ycase;
    }
    
    public int convertirAbscisseMin(int caseX) {
        int abscisseMin = MARGE + PAS * caseX;
        return abscisseMin;
    }
    
    public int convertirOrdonneeMin(int caseY) {
        int ordonneeMin = MARGE + PAS * caseY;
        return ordonneeMin;
    }
    
    public void remplirGrille(int[][] tableauARemplir, int nombre) {
        int caseX, caseY, coordX, coordY;
        coordX = x;
        coordY = y;
        caseX = convertirX(coordX);
        caseY = convertirY(coordY);
        modifierTableau(tableauARemplir, caseX, caseY, nombre);
        recupererTableau(tableauARemplir);
    }
    
    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}
}