package sudoku_alpha;

import static sudoku_alpha.Visuel.dessiner;

public class Sudoku_Alpha {
 
    public static void main(String[] args) {
        dessiner();
    }
}