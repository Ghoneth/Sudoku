package sudoku_alpha;

import static sudoku_alpha.Visuel.g1;
import static sudoku_alpha.Visuel.tableauEnCours;

public class PremAlgo {
    int[][] grille;
    int iteration=0;
    int solution;
    long tSolution;
    int[][] solution1;
   
    public PremAlgo (int[][] sudokuPartiellementVide) {
        grille=sudokuPartiellementVide;
        solution=0;
        tSolution=0;
    }
    
    public void afficherSudoku() {
        for (int ligne = 0; ligne < 9; ligne++) {
            System.out.print("{");
            for (int colonne = 0; colonne < 9; colonne++) {
                if (colonne==8) System.out.print(this.grille[ligne][colonne]);
                else System.out.print(this.grille[ligne][colonne]+ ", ");
            }
            System.out.println("}");
        }
    }
    
    public int resolverPremiere () {
        for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grille[ligne][colonne]==0) {
                    for (int valeur = 1; valeur < 10; valeur++) {
                        this.grille[ligne][colonne]=valeur;
                        if (solution==0) {
                            iteration++;
                            System.out.println();
                            System.out.println("Iteration n° : " + iteration + " de la solution n° 1"); //Affichage des nombres trouvés au fur et à mesure pour la premiere solution
                            this.afficherSudoku();
                        }
                        if (estValide()&&this.resolverPremiere()==0) return 0;
                        this.grille[ligne][colonne]=0;
                    }
                    return 1;
                }
            }
        }
        solution++; //Incrémentation du nombre de solution
        System.out.println();
        System.out.println("La solution la plus rapidement trouvée est :");
        this.afficherSudoku();
        tableauEnCours=this.grille;
        System.out.println();
        this.tSolution=new java.util.Date().getTime();
        return 0;
    }

    public boolean estValide () { 
         for (int ligne = 0; ligne < 9; ligne++) {
            for (int colonne = 0; colonne < 9; colonne++) {
                if (this.grille[ligne][colonne]!=0) {
                    int valeur = this.grille[ligne][colonne];
                    for (int index=0; index<9; index++) {
                        if (this.grille[ligne][index]==valeur) if (index!=colonne) return false;
                        if (this.grille[index][colonne]==valeur) if (index!=ligne) return false;
                    }
                    int cLigne = ligne/3;
                    int cColonne = colonne/3;
                    for (int index=0+cLigne*3; index<3+cLigne*3; index++) {
                        for (int jndex=0+cColonne*3; jndex<3+cColonne*3; jndex++) {
                            if (this.grille[index][jndex]==valeur) if (index!=ligne && jndex!=colonne) return false;
                        }
                    }
                }
            }
         }
        return true;
    }
    
    public static int[][] Algo (int [][] sudokuPartiellementVide) {
        long tDebut = new java.util.Date().getTime();
        PremAlgo sudoku = new PremAlgo (sudokuPartiellementVide);
        System.out.println("Sudoku partiellement rempli : ");
        sudoku.afficherSudoku();
        System.out.println();
        
        sudoku.resolverPremiere();
        System.out.println();
        
        if (sudoku.solution>0) {
            System.out.println("L'algo a pris " + (sudoku.tSolution - tDebut) + " milisecondes à trouver (et surtout afficher) la premiere solution");
        } 
        else {
            System.out.println("Il n'y a pas de solution");
            
        }
        return sudoku.grille;
    }
}