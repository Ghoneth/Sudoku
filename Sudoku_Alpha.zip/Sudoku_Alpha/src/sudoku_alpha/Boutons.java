package sudoku_alpha;

import java.awt. *;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing. *;

public class Boutons extends Panneau
                    implements ActionListener {
    public JButton generer, creer, resoudre, solveur, recommencer, tester, redemarrer;
    Grille grille;
    String message;
    
    public Boutons(int largeur, int hauteur, Visuel sudoku, Grille grille) {
        super(largeur, hauteur, sudoku);
        this.grille = grille;}
    
    public void creerBouton(JButton nom){
        nom.setVerticalTextPosition(AbstractButton.CENTER);
        nom.setHorizontalTextPosition(AbstractButton.LEADING);
        nom.setMnemonic(KeyEvent.VK_D);
        nom.setActionCommand("disable");
        nom.addActionListener(this);
        add(nom);
    }
    
    public void creerBoutonGenerer() {
        generer = new JButton ("Générer une grille");
        creerBouton(generer);
    }
    
    public void creerBoutonCreer() {
        creer = new JButton ("Créer une grille");
        creerBouton(creer);
    }
    
    public void creerBoutonResoudre() {
        resoudre = new JButton ("Résoudre moi-même");
        creerBouton(resoudre);
    }
    
    public void creerBoutonSolveur() {
        solveur = new JButton ("Résoudre par l'ordinateur");
        creerBouton(solveur);
    }
    
    public void creerBoutonRecommencer() {
        recommencer = new JButton ("Recommencer cette grille");
        creerBouton(recommencer);
    }
    
    public void creerBoutonTester() {
        tester = new JButton ("Vérifier mon sudoku");
        creerBouton(tester);
    }
    
    public void creerBoutonRedemarrer() {
        redemarrer = new JButton ("Redémarrer le jeu");
        creerBouton(redemarrer);
    }
    
    public void BoutonsDebut() {
        creerBoutonGenerer();
        creerBoutonCreer();
    }
    
    public void BoutonsGenerer() {
        creerBoutonResoudre();
        creerBoutonSolveur();
        creerBoutonRedemarrer();
    }
    
    public void BoutonsCreer() {
        creerBoutonSolveur();
        creerBoutonRecommencer();
        creerBoutonRedemarrer();
    }
    
    public void BoutonsResoudre() {
        creerBoutonRecommencer();
        creerBoutonRedemarrer();
    }
    
    public void effacerBoutons() {
        Component[] composantListe = getComponents();
        for (Component c: composantListe) {
            remove(c);
        }
        revalidate();
        repaint();
    }
    
    public void generer() {
        message = "Générer une grille!";
        Visuel.afficherMessage(message);
        effacerBoutons();
        BoutonsGenerer();
        Visuel.grilleTestAntoine(grille);
        Visuel.tableauEnCours = (Visuel.tableauTest);
        Visuel.tableauACreer = false;
    }
    
    public void creer() {
        message = "Créer une grille !";  
        Visuel.afficherMessage(message);
        effacerBoutons();
        BoutonsCreer();
        Visuel.tableauEnCours = grille.copierTableau(Visuel.tableauVide);
        Visuel.tableauACreer = true;
        grille.peutRemplir = true;
    }
    
    public void resoudre() {
        message = "Résoudre la grille !";
        Visuel.afficherMessage(message);
        effacerBoutons();
        BoutonsResoudre();
        grille.peutRemplir = true;
    }
    
    public void solveur() {
        message = "Résolvez la grille !";
        Visuel.afficherMessage(message);
        effacerBoutons();
        grille.peutRemplir = false;
        Visuel.grilleResolutionAntoine(grille);
    }
    
    public void recommencer() {
        message = "Recommencer la grille !";
        Visuel.afficherMessage(message);
        effacerBoutons();
        BoutonsCreer();
        if(Visuel.tableauACreer == false)  {
            Visuel.tableauEnCours = grille.copierTableau(Visuel.tableauTest);}
        else if(Visuel.tableauACreer == true) {
            Visuel.tableauEnCours = grille.copierTableau(Visuel.tableauVide);}
        Visuel.demarrage(grille);
    }
    
    public void tester() {
        message = "Tester ma grille !";
        Visuel.afficherMessage(message);
        effacerBoutons();
        grille.peutRemplir = true;
        //appeler les méthodes d'Isabelle pour tester la validité de la grille
    }
    
    public void redemarrer() {
        message = "Redémarrer le jeu !";
        Visuel.afficherMessage(message);
        effacerBoutons();
        BoutonsDebut();
        grille.peutRemplir = false;
        Visuel.tableauEnCours = grille.copierTableau(Visuel.tableauVide);
        Visuel.demarrage(grille);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == generer) {
            generer();
        }
        else if (source == creer) {
            creer();
        }
        else if (source == resoudre) {
            resoudre();
        }
        else if (source == solveur) {
            solveur();
        }
        else if (source == recommencer) {
            recommencer();
        }
        else if (source == tester) {
            tester();
        }
        else if (source == redemarrer) {
            redemarrer();
        }
    }
}