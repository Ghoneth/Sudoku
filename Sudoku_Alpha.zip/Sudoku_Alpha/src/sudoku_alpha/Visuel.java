package sudoku_alpha;

import java.awt. *;
import javax.swing. *;
import java.util.Scanner;

public class Visuel extends JFrame {
    public static Graphics g1 = null;
    static int [][] tableauVide = new int [9][9];
    static int [][] tableauTest = new int [9][9];
    static int [][] tableauEnCours;
    static boolean tableauACreer;
        
    public Visuel(int largeur, int hauteur) {
        this.setTitle("Jeu de sudoku");
        this.setSize(largeur, hauteur);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    
    public static void EntrerNombre(Grille grille, int x, int y) {
        grille.effacerGraphique(g1);
        int caseX = grille.convertirX(x);
        int caseY = grille.convertirY(y);
        int abscisseMin = grille.convertirAbscisseMin(caseX);
        int ordonneeMin = grille.convertirOrdonneeMin(caseY);
        ChampTexte saisie = new ChampTexte(abscisseMin, ordonneeMin, grille);
    }
        
    public static void grilleARemplir(Grille grille, int nombre) {
        grille.remplirGrille(tableauEnCours, nombre);
    }
    
    public static void demarrage(Grille grille) {
        grille.effacerGraphique(g1);
        grille.recupererTableau(tableauEnCours);
    }
    
    public static void grilleTestAntoine(Grille grille) {
        grille.effacerGraphique(g1);
        int[][] tableauTemp = GenererSudoku.genererAleatoire();
        grille.recupererTableau(tableauTemp);
        tableauTest=tableauTemp;
    }
        
    public static void grilleResolutionAntoine(Grille grille) {
        grille.effacerGraphique(g1);
        int[][] tableauTemp = PremAlgo.Algo(tableauEnCours);
        grille.recupererTableau(tableauTemp);
        tableauEnCours=tableauTemp;
    }
    
    public static void dessiner() {
        Visuel fenetre = new Visuel (800, 800);
        Panneau panneau = new Panneau(800, 800, fenetre);
        Grille grille = new Grille(500, 500, fenetre);
        Boutons boutons = new Boutons(200,100, fenetre, grille);
        Titre titre = new Titre(800, 150, fenetre);
        grille.paint(g1);
        Color fond = new Color(90, 0, 0);
        
        panneau.setBackground(fond);
        titre.setOpaque(false);
        panneau.add(titre, BorderLayout.PAGE_START);
        grille.setOpaque(false);
        panneau.add(grille, BorderLayout.LINE_START);
        boutons.setOpaque(false);
        panneau.add(boutons, BorderLayout.LINE_END);
        fenetre.setContentPane(panneau);
        
        tableauEnCours = grille.copierTableau(tableauVide);
        demarrage(grille);
        boutons.BoutonsDebut();
        titre.ajouterTitre();
    }
}