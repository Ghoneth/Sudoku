import java.awt. *;
import javax.swing. *;

public class Panneau extends JPanel {
    public Panneau(int largeur, int hauteur){
        this.setPreferredSize(new Dimension(largeur, hauteur));
        this.setVisible(true);
    }
}
