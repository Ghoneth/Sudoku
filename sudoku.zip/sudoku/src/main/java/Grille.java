import java.awt. *;
import javax.swing. *;

public class Grille extends Panneau {
    public Grille(int largeur, int hauteur) {
        super(largeur, hauteur);
    }
    
    protected void paintComponent(Graphics g) {
        final int MARGE = 50;
        final int PAS = 45;
        for (int coord = 0; coord < 10 ; coord ++) {
            g.drawLine(MARGE + PAS*coord, MARGE, MARGE + PAS*coord, MARGE + PAS*9);
            g.drawLine(MARGE, MARGE + PAS*coord, MARGE + PAS*9, MARGE + PAS*coord);
        }
    }
}
