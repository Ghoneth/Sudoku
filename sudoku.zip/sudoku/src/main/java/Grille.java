import java.awt. *;
import javax.swing. *;

public class Grille extends Panneau {
    public Grille(int largeur, int hauteur) {
        super(largeur, hauteur);
    }
    
    protected void paintComponent(Graphics g) {
        final int MARGE_HAUT = 200;
        final int MARGE_GAUCHE = 100;
        final int PAS = 45;
        for (int coord = 0; coord < 10 ; coord ++) {
            g.drawLine(MARGE_GAUCHE + PAS*coord, MARGE_HAUT, MARGE_GAUCHE + PAS*coord, MARGE_HAUT + PAS*9);
            g.drawLine(MARGE_GAUCHE, MARGE_HAUT + PAS*coord, MARGE_GAUCHE + PAS*9, MARGE_HAUT + PAS*coord); 
            if (coord == 0 || coord == 3 || coord == 6 || coord == 9) {
                g.drawLine(MARGE_GAUCHE + 1 + PAS*coord, MARGE_HAUT, MARGE_GAUCHE + 1 + PAS*coord, MARGE_HAUT + PAS*9);
                g.drawLine(MARGE_GAUCHE - 1 + PAS*coord, MARGE_HAUT, MARGE_GAUCHE - 1 + PAS*coord, MARGE_HAUT + PAS*9);
                g.drawLine(MARGE_GAUCHE, MARGE_HAUT + 1 + PAS*coord, MARGE_GAUCHE + PAS*9, MARGE_HAUT + 1 + PAS*coord); 
                g.drawLine(MARGE_GAUCHE, MARGE_HAUT - 1 + PAS*coord, MARGE_GAUCHE + PAS*9, MARGE_HAUT - 1 + PAS*coord); 
            }
        }
    }
}
