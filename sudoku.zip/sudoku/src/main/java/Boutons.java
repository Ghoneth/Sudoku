import java.awt. *;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing. *;

public class Boutons extends Panneau 
                    implements ActionListener {
    public JButton generer, creer;
    public Boutons(int largeur, int hauteur) {
        super(largeur, hauteur);
        generer = new JButton ("Générer une grille");
        generer.setVerticalTextPosition(AbstractButton.CENTER);
        generer.setHorizontalTextPosition(AbstractButton.LEADING);
        generer.setMnemonic(KeyEvent.VK_D);
        generer.setActionCommand("disable");
        
        creer = new JButton ("Créer une grille");
        creer.setVerticalTextPosition(AbstractButton.CENTER);
        creer.setHorizontalTextPosition(AbstractButton.LEADING);
        creer.setMnemonic(KeyEvent.VK_D);
        creer.setActionCommand("disable");
        
        generer.addActionListener(this);
        creer.addActionListener(this);
        add(generer);
        add(creer);
    }
    
    public void actionPerformed(ActionEvent e) {
        if ("disable".equals(e.getActionCommand())) {
            generer.setEnabled(false);
            creer.setEnabled(false);} 
        else {
            generer.setEnabled(true);
            creer.setEnabled(true);}
    }   
    
}
