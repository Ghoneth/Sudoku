package sudoku;

import java.awt. *;
import javax.swing. *;

public class Panneau extends JPanel {
    Sudoku fenetre;
    
    public Panneau(int largeur, int hauteur, Sudoku sudoku) {
        this.setPreferredSize(new Dimension(largeur, hauteur));
        this.setVisible(true);
        this.fenetre = sudoku;}
}
