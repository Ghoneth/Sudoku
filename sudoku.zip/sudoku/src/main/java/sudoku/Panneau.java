package sudoku;

//On importe les bibliothèques dont on a besoin pour la classe Panneau

import java.awt. *;
import javax.swing. *;

/*
Puis on créer la classe Panneau, étandant la classe Jpanel, ainsi que son constructeur.
On pense à ses dimensions et on l'affiche grâçe à setVisible(true).
*/

public class Panneau extends JPanel {
    public Panneau(int largeur, int hauteur){
        this.setPreferredSize(new Dimension(largeur, hauteur));
        this.setVisible(true);
    }
}
