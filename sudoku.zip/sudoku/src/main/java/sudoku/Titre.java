package sudoku;

//On importe les bibliothèques dont on a besoin pour la classe Titre

import java.awt. *;
import javax.swing. *;

/*
Puis on créer la classe Grille, étandant la classe Panneau, et donc indirectement la classe Jpanel, ainsi que son constructeur.
On pense à ses dimensions qui sont hérités de la classe Panneau.
*/

public class Titre extends Panneau {
    public Titre(int largeur, int hauteur) {
        super(largeur, hauteur);
    }
}
