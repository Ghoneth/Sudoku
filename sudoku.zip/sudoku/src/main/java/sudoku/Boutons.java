package sudoku;

import java.awt. *;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing. *;

public class Boutons extends Panneau
                    implements ActionListener {
    public JButton generer, creer, resoudre, solveur, recommencer, tester, redemarrer;
    Grille grille;
    
    public Boutons(int largeur, int hauteur, Sudoku sudoku, Grille grille) {
        super(largeur, hauteur, sudoku);
        this.grille = grille;}
    
    public void creerBoutonGenerer() {
        generer = new JButton ("Générer une grille");
        generer.setVerticalTextPosition(AbstractButton.CENTER);
        generer.setHorizontalTextPosition(AbstractButton.LEADING);
        generer.setMnemonic(KeyEvent.VK_D);
        generer.setActionCommand("disable");
        generer.addActionListener(this);
        add(generer);
    }
    
    public void creerBoutonCreer() {
        creer = new JButton ("Créer une grille");
        creer.setVerticalTextPosition(AbstractButton.CENTER);
        creer.setHorizontalTextPosition(AbstractButton.LEADING);
        creer.setMnemonic(KeyEvent.VK_D);
        creer.setActionCommand("disable");
        creer.addActionListener(this);
        add(creer);
    }
    
    public void creerBoutonResoudre() {
        resoudre = new JButton ("Résoudre moi-même");
        resoudre.setVerticalTextPosition(AbstractButton.CENTER);
        resoudre.setHorizontalTextPosition(AbstractButton.LEADING);
        resoudre.setMnemonic(KeyEvent.VK_D);
        resoudre.setActionCommand("disable");
        resoudre.addActionListener(this);
        add(resoudre);
    }
    
    public void creerBoutonSolveur() {
        solveur = new JButton ("Résoudre par l'ordinateur");
        solveur.setVerticalTextPosition(AbstractButton.CENTER);
        solveur.setHorizontalTextPosition(AbstractButton.LEADING);
        solveur.setMnemonic(KeyEvent.VK_D);
        solveur.setActionCommand("disable");
        solveur.addActionListener(this);
        add(solveur);
    }
    
    public void creerBoutonRedemarrer() {
        redemarrer = new JButton ("Redémarrer le jeu");
        redemarrer.setVerticalTextPosition(AbstractButton.CENTER);
        redemarrer.setHorizontalTextPosition(AbstractButton.LEADING);
        redemarrer.setMnemonic(KeyEvent.VK_D);
        redemarrer.setActionCommand("disable");
        redemarrer.addActionListener(this);
        add(redemarrer);
    }
    
    public void creerBoutonRecommencer() {
        recommencer = new JButton ("Recommencer cette grille");
        recommencer.setVerticalTextPosition(AbstractButton.CENTER);
        recommencer.setHorizontalTextPosition(AbstractButton.LEADING);
        recommencer.setMnemonic(KeyEvent.VK_D);
        recommencer.setActionCommand("disable");
        recommencer.addActionListener(this);
        add(recommencer);
    }
    
    public void creerBoutonTester() {
        tester = new JButton ("Vérifier mon sudoku");
        tester.setVerticalTextPosition(AbstractButton.CENTER);
        tester.setHorizontalTextPosition(AbstractButton.LEADING);
        tester.setMnemonic(KeyEvent.VK_D);
        tester.setActionCommand("disable");
        tester.addActionListener(this);
        add(tester);
    }
    
    public void BoutonsDebut() {
        creerBoutonGenerer();
        creerBoutonCreer();
    }
    
    public void BoutonsGenerer() {
        creerBoutonResoudre();
        creerBoutonSolveur();
        creerBoutonRedemarrer();
    }
    
    public void BoutonsCreer() {
        creerBoutonSolveur();
        creerBoutonRedemarrer();
        creerBoutonRecommencer();
    }
    
    public void BoutonsJouer() {
        creerBoutonRecommencer();
        creerBoutonRedemarrer();
    }
    
    public void effacerBoutons() {
        Component[] composantListe = getComponents();
        for (Component c: composantListe) {
            remove(c);
        }
        revalidate();
        repaint();
    }
    
    public void generer() {
        System.out.println("Générer une grille!");
        effacerBoutons();
        BoutonsGenerer();
        Sudoku.grilleTest(grille);
    }
    
    public void creer() {
        System.out.println("Créer une grille !");            
        effacerBoutons();
        BoutonsCreer();
        //laisser l'utilisateur remplir la grille
    }
    
    public void tester() {
        System.out.println("Tester ma grille !");
        effacerBoutons();
        //appeler les méthodes d'Isabelle
    }
    
    public void recommencer() {
        System.out.println("Recommencer la grille !");
        effacerBoutons();
        BoutonsCreer();
        Sudoku.grilleTest(grille);
    }
    
    public void solveur() {
        System.out.println("Résolvez la grille !");
        effacerBoutons();
        //appeler les méthodes d'Antoine
    }
    
    public void jouer() {
        System.out.println("Résoudre la grille !");
        effacerBoutons();
        BoutonsJouer();
        //laisser l'utilisateur remplir la grille
    }
    
    public void redemarrer() {
        System.out.println("Redémarrer le jeu !");
        effacerBoutons();
        BoutonsDebut();
        Sudoku.demarrage(grille);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == generer) {
            generer();
        }
        else if (source == creer) {
            creer();
        }
        else if (source == tester) {
            tester();
        }
        else if (source == recommencer) {
            recommencer();
        }
        else if (source == solveur) {
            solveur();
        }
        else if (source == resoudre) {
            jouer();
        }
        else if (source == redemarrer) {
            redemarrer();
        }
    }
}