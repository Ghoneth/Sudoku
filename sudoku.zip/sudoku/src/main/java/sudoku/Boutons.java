package sudoku;

//On importe les bibliothèques dont on a besoin pour la classe Boutons

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing. *;

/*
Puis on créer la classe Boutons, étandant la classe Panneau et donc indirectement la classe Jpanel, ainsi que son constructeur.
On pense à ses dimensions qui sont hérités de la classe Panneau.
Cette classe implémente la classe ActionListener qui permet entre autre le fonctionnement des boutons en java.
On créer aussi des boutons generer et creer qui permettront à l'utilisateur de choisir s'il souhaite faire générer une grille et la
résoudre lui-même/la faire résoudre par l'ordinateur (ce qui arrivera sur une autre page); ou créer sa propre grille et la faire
résoudre par l'ordinateur.
*/

public class Boutons extends Panneau 
                    implements ActionListener {
    public JButton generer, creer;
    public Boutons(int largeur, int hauteur) {
        super(largeur, hauteur);
        generer = new JButton ("Générer une grille");
        generer.setVerticalTextPosition(AbstractButton.CENTER);
        generer.setHorizontalTextPosition(AbstractButton.LEADING);
        generer.setMnemonic(KeyEvent.VK_D);
        generer.setActionCommand("disable");
        
        creer = new JButton ("Créer une grille");
        creer.setVerticalTextPosition(AbstractButton.CENTER);
        creer.setHorizontalTextPosition(AbstractButton.LEADING);
        creer.setMnemonic(KeyEvent.VK_D);
        creer.setActionCommand("disable");
        
        generer.addActionListener(this);
        creer.addActionListener(this);
        add(generer);
        add(creer);
    }
    
    //Enfin, on créer une méthode qui permet d'activer un évènement lorsque l'utilisateur clique sur un bouton.
    
    public void actionPerformed(ActionEvent e) {
        if ("disable".equals(e.getActionCommand())) {
            generer.setEnabled(false);
            creer.setEnabled(false);} 
        else {
            generer.setEnabled(true);
            creer.setEnabled(true);}
    }   
    
}
