package sudoku;

import java.awt. *;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing. *;

public class Boutons extends Panneau
                    implements ActionListener {
    public JButton generer, creer, resoudre, solveur, recommencer, tester, redemarrer;
    Grille grille;
    
    public Boutons(int largeur, int hauteur, Sudoku sudoku, Grille grille) {
        super(largeur, hauteur, sudoku);
        this.grille = grille;}
    
    public void BoutonsDebut() {
        generer = new JButton ("Générer une grille");
        generer.setVerticalTextPosition(AbstractButton.CENTER);
        generer.setHorizontalTextPosition(AbstractButton.LEADING);
        generer.setMnemonic(KeyEvent.VK_D);
        generer.setActionCommand("disable");
        
        creer = new JButton ("Créer une grille");
        creer.setVerticalTextPosition(AbstractButton.CENTER);
        creer.setHorizontalTextPosition(AbstractButton.LEADING);
        creer.setMnemonic(KeyEvent.VK_D);
        creer.setActionCommand("disable");
        
        generer.addActionListener(this);
        creer.addActionListener(this);
        add(generer);
        add(creer);
    }
    
    public void BoutonsGenerer() {
        resoudre = new JButton ("Résoudre moi-même");
        resoudre.setVerticalTextPosition(AbstractButton.CENTER);
        resoudre.setHorizontalTextPosition(AbstractButton.LEADING);
        resoudre.setMnemonic(KeyEvent.VK_D);
        resoudre.setActionCommand("disable");
        
        solveur = new JButton ("Résoudre par l'ordinateur");
        solveur.setVerticalTextPosition(AbstractButton.CENTER);
        solveur.setHorizontalTextPosition(AbstractButton.LEADING);
        solveur.setMnemonic(KeyEvent.VK_D);
        solveur.setActionCommand("disable");
        
        redemarrer = new JButton ("Redémarrer le jeu");
        redemarrer.setVerticalTextPosition(AbstractButton.CENTER);
        redemarrer.setHorizontalTextPosition(AbstractButton.LEADING);
        redemarrer.setMnemonic(KeyEvent.VK_D);
        redemarrer.setActionCommand("disable");
        
        resoudre.addActionListener(this);
        solveur.addActionListener(this);
        redemarrer.addActionListener(this);
        add(resoudre);
        add(solveur);
        add(redemarrer);
    }
    
    public void BoutonsCreer() {
        solveur = new JButton ("Résoudre par l'ordinateur");
        solveur.setVerticalTextPosition(AbstractButton.CENTER);
        solveur.setHorizontalTextPosition(AbstractButton.LEADING);
        solveur.setMnemonic(KeyEvent.VK_D);
        solveur.setActionCommand("disable");
        
        recommencer = new JButton ("Recommencer cette grille");
        recommencer.setVerticalTextPosition(AbstractButton.CENTER);
        recommencer.setHorizontalTextPosition(AbstractButton.LEADING);
        recommencer.setMnemonic(KeyEvent.VK_D);
        recommencer.setActionCommand("disable");
        
        redemarrer = new JButton ("Redémarrer le jeu");
        redemarrer.setVerticalTextPosition(AbstractButton.CENTER);
        redemarrer.setHorizontalTextPosition(AbstractButton.LEADING);
        redemarrer.setMnemonic(KeyEvent.VK_D);
        redemarrer.setActionCommand("disable");
        
        solveur.addActionListener(this);
        recommencer.addActionListener(this);
        redemarrer.addActionListener(this);
        add(solveur);
        add(recommencer);
        add(redemarrer);
    }
    
    public void BoutonsJouer() {
        tester = new JButton ("Vérifier mon sudoku");
        tester.setVerticalTextPosition(AbstractButton.CENTER);
        tester.setHorizontalTextPosition(AbstractButton.LEADING);
        tester.setMnemonic(KeyEvent.VK_D);
        tester.setActionCommand("disable");
        
        recommencer = new JButton ("Recommencer cette grille");
        recommencer.setVerticalTextPosition(AbstractButton.CENTER);
        recommencer.setHorizontalTextPosition(AbstractButton.LEADING);
        recommencer.setMnemonic(KeyEvent.VK_D);
        recommencer.setActionCommand("disable");
        
        redemarrer = new JButton ("Redémarrer le jeu");
        redemarrer.setVerticalTextPosition(AbstractButton.CENTER);
        redemarrer.setHorizontalTextPosition(AbstractButton.LEADING);
        redemarrer.setMnemonic(KeyEvent.VK_D);
        redemarrer.setActionCommand("disable");
        
        tester.addActionListener(this);
        recommencer.addActionListener(this);
        redemarrer.addActionListener(this);
        add(tester);
        add(recommencer);
        add(redemarrer);
    }
    
    public void effacerBoutons() {
        Component[] composantListe = getComponents();
        for (Component c: composantListe) {
            remove(c);
        }
        revalidate();
        repaint();
    }
    
    public void generer() {
        effacerBoutons();
        BoutonsGenerer();
        Sudoku.nouvelleGrille(grille);
    }
    
    public void creer() {            
        effacerBoutons();
        BoutonsCreer();
        //laisser l'utilisateur remplir la grille
    }
    
    public void tester() {
        effacerBoutons();
        //appeler les méthodes d'Isabelle
    }
    
    public void recommencer() {
        effacerBoutons();
        BoutonsCreer();
        Sudoku.nouvelleGrille(grille);
    }
    
    public void solveur() {
        effacerBoutons();
        //appeler les méthodes d'Antoine
    }
    
    public void jouer() {
        effacerBoutons();
        BoutonsJouer();
        //laisser l'utilisateur remplir la grille
    }
    
    public void redemarrer() {
        effacerBoutons();
        BoutonsDebut();
        Sudoku.demarrage(grille);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == generer) {
            System.out.println("Générer une grille!");
            generer();
        }
        else if (source == creer) {
            System.out.println("Créer une grille !");
            creer();
        }
        else if (source == tester) {
            System.out.println("Tester ma grille !");
            tester();
        }
        else if (source == recommencer) {
            System.out.println("Recommencer la grille !");
            recommencer();
        }
        else if (source == solveur) {
            System.out.println("Résolvez la grille !");
            solveur();
        }
        else if (source == resoudre) {
            System.out.println("Résoudre la grille !");
            jouer();
        }
        else if (source == redemarrer) {
            System.out.println("Redémarrer le jeu !");
            redemarrer();
        }
    }
}