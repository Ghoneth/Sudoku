package sudoku;

//On importe les bibliothèques dont on a besoin pour la classe Sudoku

import java.awt. *;
import javax.swing. *;

/*
On déclare la classe Sudoku et son constructeur
Celle-ci représentant la fenêtre principale du jeu, on lui veut une hauteur et une largeur;
Comme il ni y aura de toute façon qu'une fenêtre, on se permet de lui donner les paramètres que l'on veut ici :
Dans l'ordre on a le titre de la page, sa taille (leurgeur et hauteur), un paramètre permettant de la fermer à l'aide de la croix,
un ordre l'empêchant d'être redimensionné par d'autres facteurs, sa position par rapport à l'écran de l'utilisateur,
puis on la rend visible.
*/

public class Sudoku extends JFrame {
    public Sudoku(int largeur, int hauteur) {
        this.setTitle("Jeu de sudoku");
        this.setSize(largeur, hauteur);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
    
    /*
    On déclare une méthode propre à l'affichage du démarrage du programme
    en outre, la fenêtre contiendra un contenant principal qui accueillera un panneau pour la grille, un panneau pour les boutons
    et un panneau pour le titre comme décrit dans le rappor/pseudo code.
    Chacun d'eux sont naturellement déclarés comme étant des objets de la classe Panneau (car leur classe étandent la classe Jpanel).
    On créer alors ces objets, on leur attribue une largeur et une hauteur, pour certains une couleur ou des paramètres d'opacité...
    C'est en ajoutant chacun des sous-panneau au contenant principal panneau que l'on en profite pour les agencer grâçe au BorderLayout.
    Enfin, on remplace le contenant principal de la fenêtre de sudoku par le panneau que l'on vient de décrire.
    */
    
    public static void demarrage(Sudoku fenetre) {
        Panneau panneau, grille, boutons, titre;
        panneau = new Panneau(800, 800);
        panneau.setBackground(Color.lightGray);
        titre = new Titre(800, 150);
        panneau.add(titre, BorderLayout.PAGE_START);
        grille = new Grille(500, 500);
        panneau.add(grille, BorderLayout.LINE_START);
        boutons = new Boutons(200,100);
        boutons.setOpaque(false);
        panneau.add(boutons, BorderLayout.LINE_END);
        fenetre.setContentPane(panneau);
    }
    
    /*
    On a ici la méthode main, coeur du programme, qui créer la fenêtre de jeu fenetre, lui attribue les dimensions 800x800
    et appelle la méthode demarrage(fenetre) afin de remplir cette fenêtre avec le contenu souhaité au démarrage.
    */
    
    public static void main(String[] args) {
        Sudoku fenetre;
        fenetre = new Sudoku (800, 800);
        
        demarrage(fenetre);
    }
    
}
