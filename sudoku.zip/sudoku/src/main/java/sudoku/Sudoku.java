package sudoku;

import java.awt. *;
import javax.swing. *;
import java.util.Scanner;

public class Sudoku extends JFrame {
    public static Graphics g1 = null;
    static int [][] tableauVide = new int [9][9];
    static int [][] tableauTest = new int [9][9];
    static int [][] tableauEnCours;
    static boolean tableauACreer;
        
    public Sudoku(int largeur, int hauteur) {
        this.setTitle("Jeu de sudoku");
        this.setSize(largeur, hauteur);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    
    public static boolean testErreur(int nombre) {
        if (nombre >= 0 && nombre <= 9) {
            return true;}
        return false;
    }
    
    public static int entrerNombre() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre compris entre 1 et 9:");
        return sc.nextInt();
    }
    
    public static void demarrage(Grille grille) {
        grille.effacerGraphique(g1);
        grille.recupererTableau(tableauEnCours);
    }
    
    // Je définis une grille "test", en réalité cette grille sera celle générée par les méthodes d'Isabelle
    public static void grilleTest(Grille grille) {
        grille.effacerGraphique(g1);
        grille.modifierTableau(tableauTest, 4, 5, 7);
        grille.modifierTableau(tableauTest, 1, 2, 3);
        grille.modifierTableau(tableauTest, 8, 8, 2);
        grille.modifierTableau(tableauTest, 7, 0, 9);
        grille.modifierTableau(tableauTest, 1, 1, 8);
        grille.recupererTableau(tableauTest);
    }
    
    public static void grilleARemplir(Grille grille) {
        grille.effacerGraphique(g1);
        int nombre = entrerNombre();
        if (testErreur(nombre) == true){
            grille.remplirGrille(tableauEnCours, nombre);}
        else {
            System.out.println("Veuillez entrez un nombre compris entre 0 et 9 !");}
    }
    
    public static void main(String[] args) {
        Sudoku fenetre = new Sudoku (800, 800);
        Panneau panneau = new Panneau(800, 800, fenetre);
        Grille grille = new Grille(500, 500, fenetre);
        Boutons boutons = new Boutons(200,100, fenetre, grille);
        Titre titre = new Titre(800, 150, fenetre);
        grille.paint(g1);
        
        panneau.setBackground(Color.lightGray);
        panneau.add(titre, BorderLayout.PAGE_START);
        grille.setOpaque(false);
        panneau.add(grille, BorderLayout.LINE_START);
        boutons.setOpaque(false);
        panneau.add(boutons, BorderLayout.LINE_END);
        fenetre.setContentPane(panneau);
        
        tableauEnCours = grille.copierTableau(tableauVide);
        demarrage(grille);
        boutons.BoutonsDebut();
    }
}
