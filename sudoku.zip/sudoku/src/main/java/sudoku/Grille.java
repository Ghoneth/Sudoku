package sudoku;

import java.awt. *;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing. *;

public class Grille extends Panneau 
                    implements MouseListener, ActionListener {
    
    final int MARGE = 50;
    final int PAS = 45;
    int[][] grilleSudoku;
    int x;
    int y;
    //String [] listeNombres = {"0","1","2","3","4","5","6","7","8","9"};
    //JComboBox choix = new JComboBox(listeNombres);
        
    public Grille(int largeur, int hauteur, Sudoku sudoku) {
        super(largeur, hauteur, sudoku);
        this.addMouseListener(this);
        //choix.addActionListener(this);
    }
    
    public void recupererTableau(int[][] tableau){
        grilleSudoku = tableau;
    }
    
    public int [][] modifierTableau(int [][] tableau, int colonne, int ligne, int nouvelleValeur) {
        tableau[ligne][colonne] = nouvelleValeur;
        return tableau;
    }
    
    public int obtenirValeur(int[][] tableau, int ligne, int colonne) {
        int valeur = tableau[ligne][colonne];
        return valeur;
    }
    
    public String obtenirCaractere(int[][] tableau, int ligne, int colonne) {
        int valeur = obtenirValeur(tableau, ligne, colonne);
        String caractere = String.valueOf(valeur);
        return caractere;
    }
    
    public void afficherGrille(Graphics g) {
        for (int coord = 0; coord < 10 ; coord ++) {
            g.drawLine(MARGE + PAS*coord, MARGE, MARGE + PAS*coord, MARGE + PAS*9);
            g.drawLine(MARGE, MARGE + PAS*coord, MARGE + PAS*9, MARGE + PAS*coord);
            if (coord == 0 || coord == 3 || coord == 6 || coord == 9) {
                g.drawLine(MARGE + PAS*coord - 1, MARGE, MARGE + PAS*coord - 1, MARGE + PAS*9);
                g.drawLine(MARGE + PAS*coord + 1, MARGE, MARGE + PAS*coord + 1, MARGE + PAS*9);
                g.drawLine(MARGE, MARGE + PAS*coord - 1, MARGE + PAS*9, MARGE + PAS*coord - 1);
                g.drawLine(MARGE, MARGE + PAS*coord + 1, MARGE + PAS*9, MARGE + PAS*coord + 1);}
        }
    }
    
    public void afficherTableau(Graphics g, int[][] tableau) {    
        String texte;
        int abscisse;
        int ordonnee;
        for (int nbcolonne = 0; nbcolonne < 9 ; nbcolonne ++) {
            for (int nbligne = 0; nbligne < 9 ; nbligne ++) {
                texte = obtenirCaractere(tableau, nbligne, nbcolonne);
                abscisse = MARGE+PAS*1/3 + PAS*nbcolonne;
                ordonnee = MARGE+PAS*2/3 + PAS*nbligne;
                g.drawString(texte, abscisse, ordonnee);} }
    }
    
    public void effacerGraphique(Graphics g) {
        removeAll();
        repaint();
    }
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics g1 = g;
        super.paintComponent(g1);
        Font fonte = new Font(" TimesRoman ",Font.PLAIN,25);
        g.setFont(fonte);
        afficherGrille(g);
        afficherTableau(g, grilleSudoku);
    }  
    
    @Override
    public void mouseClicked(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        Sudoku.grilleARemplir(this);
    }
    
    public int retournerX() {
        return x;
    }
    
    public int retournerY() {
        return y;
    }
    
    public int convertirX(int coordX) {
        int xcase = 0;
	for (int carre = 0; carre < 10; carre++) {
            if ((coordX > MARGE+PAS*carre) && (coordX < MARGE+PAS*(carre+1))) {
                xcase = carre; } }
	return xcase;
    }
    
    public int convertirY(int coordY) {
        int ycase = 0;
	for (int carre = 0; carre < 10; carre++) {
            if ((coordY > MARGE+PAS*carre) && (coordY < MARGE+PAS*(carre+1))) {
                ycase = carre; } }
	return ycase;
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
