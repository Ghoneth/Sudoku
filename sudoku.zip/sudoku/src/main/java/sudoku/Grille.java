package sudoku;

//On importe les bibliothèques dont on a besoin pour la classe Grille

import java.awt. *;
import javax.swing. *;

/*
Puis on créer la classe Grille, étandant la classe Panneau, et donc indirectement la classe Jpanel, ainsi que son constructeur.
On pense à ses dimensions qui sont hérités de la classe Panneau.
*/

public class Grille extends Panneau {
    public Grille(int largeur, int hauteur) {
        super(largeur, hauteur);
    }
    
    /*
    On déclare également une méthode protected (car elle ne sera pas utilisé par d'autres classes) qui permettra de dessiner la grille
    de sudoku : pour cela on initialise des variables entières pour la marge et pour le pas, puis on leur attribue la taille en pixels
    souhaité.
    Une simple boucle répétant ainsi 10 traits verticaux et 10 trais horizontaux, avec les coordonnées décrites dans le rapport, 
    permet de tracer une grille.
    */
    
    protected void paintComponent(Graphics g) {
        final int MARGE = 50;
        final int PAS = 45;
        for (int coord = 0; coord < 10 ; coord ++) {
            g.drawLine(MARGE + PAS*coord, MARGE, MARGE + PAS*coord, MARGE + PAS*9);
            g.drawLine(MARGE, MARGE + PAS*coord, MARGE + PAS*9, MARGE + PAS*coord);
        }
    }
}
