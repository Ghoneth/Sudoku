import java.awt. *;
import javax.swing. *;

public class Sudoku extends JFrame {
    public Sudoku(int largeur, int hauteur) {
        this.setTitle("Jeu de sudoku");
        this.setSize(largeur, hauteur);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    
    public static void main(String[] args) {
        Sudoku fenetre;
        fenetre = new Sudoku (750, 800);
        
        Panneau panneau, grille, boutons, titre;
        panneau = new Panneau(750, 800);
        panneau.setBackground(Color.lightGray);
        titre = new Titre(750, 150);
        panneau.add(titre, BorderLayout.PAGE_START);
        grille = new Grille(500, 500);
        panneau.add(grille, BorderLayout.LINE_START);
        boutons = new Boutons(200,100);
        boutons.setOpaque(false);
        panneau.add(boutons, BorderLayout.LINE_END);
        fenetre.setContentPane(panneau);
    }
    
}
