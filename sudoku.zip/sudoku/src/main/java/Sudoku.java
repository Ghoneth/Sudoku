import java.awt. *;
import javax.swing. *;

public class Sudoku extends JFrame {
    public Sudoku(int largeur, int hauteur) {
        this.setTitle("Jeu de sudoku");
        this.setSize(largeur, hauteur);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
    
    public static void main(String[] args) {
        Sudoku fenetre;
        fenetre = new Sudoku (750, 800);
        
        Panneau panneau, grille;
        panneau = new Panneau(750, 800);
        grille = new Grille (650, 650);
        panneau.setBackground(Color.gray);
        panneau.add(grille);
        fenetre.setContentPane(panneau);
    }
    
}
