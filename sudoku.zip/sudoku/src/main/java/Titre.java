import java.awt. *;
import javax.swing. *;

public class Titre extends Panneau {
    public Titre(int largeur, int hauteur) {
        super(largeur, hauteur);
    }
}
