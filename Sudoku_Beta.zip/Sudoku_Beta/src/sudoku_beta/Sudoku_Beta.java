package sudoku_beta;
import static sudoku_beta.Visuel.dessiner;

/**Classe principale de lancement du programme. 
 * @author Antoine
 */
public class Sudoku_Beta {
    
    /** Méthode principale lançant le programme.
     * @param args Néant.
     */
    public static void main(String[] args) {
        dessiner();
    }
}