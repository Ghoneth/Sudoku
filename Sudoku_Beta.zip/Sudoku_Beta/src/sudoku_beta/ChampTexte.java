package sudoku_beta;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JTextField ;

/**Classe créant les champs de texte pour les cases du sudoku implementant
 * KeyListener pour prendre en compte les actions du clavier.
 * @author Fanny
 **/
public class ChampTexte implements KeyListener {
    Grille grille;
    JTextField strNombre;
    String message;
    
    /**Constructeur créant un champ de texte pour une case du sudoku.
     * Le constructeur lance addKeyListener permettant de prendre en compte
     * les actions du clavier dans le champ de texte.
     * @param abscisse Abscisse minimum du champ de texte.
     * @param ordonnee Ordonnée minimum du champ de texte.
     * @param grille La grille 9x9 du sudoku.
     **/
    public ChampTexte(int abscisse, int ordonnee, Grille grille) {
        JTextField strNombre = new JTextField();
        Font font = new Font(" TimesRoman ", Font.PLAIN, 25);
        Color fond = new Color(90, 0, 0);
        this.grille = grille;
        
        strNombre.setFont(font);
        strNombre.setForeground(Color.black);
        strNombre.setBackground(fond);
        strNombre.setHorizontalAlignment(JTextField.CENTER); 
        strNombre.setBounds(abscisse, ordonnee, 45, 45);
        strNombre.addKeyListener(this);
        
        grille.add(strNombre);
        grille.repaint();
    }
    
    /**Methode implementant l'action du clavier dans le champ de texte.
     * La méthode refuse un nombre déjà présent dans la ligne, colonne ou bloc 3x3 par test de validité et
     * refuse également tout caractère autre qu'un nombre entier entre 0 et 9 compris. Si refus, alors est
     * affiché un message d'explication du probleme par lancement de Visuel.afficherMessage(message).
     * Si le caractère respecte les conditions, la méthode Visuel.grilleARemplir(grille,nombre) est lancée.
     * @param e Action du clavier.
     **/
    @Override public void keyReleased(KeyEvent e) {
        int nombre = 0;
        char texte = e.getKeyChar();
        switch(texte) {
            case '0' :
                nombre = 0;
                break;
            case '1' :
                nombre = 1;
                break;
            case '2' :
                nombre = 2;
                break;
            case '3' :
                nombre = 3;
                break;
            case '4' :
                nombre = 4;
                break;
            case '5' :
                nombre = 5;
                break;
            case '6' :
                nombre = 6;
                break;
            case '7' :
                nombre = 7;
                break;
            case '8' :
                nombre = 8;
                break;
            case '9' :
                nombre = 9;
                break;
            default :
                message = "Veuillez entrez un nombre compris entre 0 et 9 !";
                Visuel.afficherMessage(message);
                break;
            }
        Visuel.grilleARemplir(grille, nombre);
        if (!Algo_Sudoku.estValide(grille.grilleSudoku, true)) {
            message = "Ce nombre est déjà présent dans une ligne, colonne ou bloc";
            Visuel.afficherMessage(message);
            Visuel.grilleARemplir(grille, 0);
        }
    }
    
    /**Methode non utilisée.
     * @param e Néant
     **/
    @Override public void keyPressed(KeyEvent e) {}
    
    /**Methode non utilisée.
     * @param e Néant
     **/
    @Override public void keyTyped(KeyEvent e) {}
}